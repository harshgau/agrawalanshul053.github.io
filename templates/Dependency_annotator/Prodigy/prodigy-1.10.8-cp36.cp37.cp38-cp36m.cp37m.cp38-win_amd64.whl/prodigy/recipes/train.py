from typing import List, Optional, Union, Tuple, Any, Sequence, Dict, Set
from spacy.gold import docs_to_json, biluo_tags_from_offsets, spans_from_biluo_tags
from spacy.util import fix_random_seed, compounding, minibatch
import spacy
import srsly
import tqdm
import random
from collections import defaultdict
from pathlib import Path

from ..core import recipe
from ..components.db import connect
from ..components.preprocess import convert_options_to_cats
from ..components.validate import validate
from ..components import printers
from ..types import NerExample, TextcatExample, PosExample, DepExample
from ..models import AnnotationModels, merge_spans, merge_tags, merge_arcs
from ..util import log, set_hashes, split_string, filter_offsets, msg, get_msg
from ..util import load_pretrained_tok2vec, read_pretrain_hyper_params
from ..util import INPUT_HASH_ATTR, get_config


SUPPORTED_COMPONENTS = ["ner", "textcat", "tagger", "parser"]


@recipe(
    "train",
    # fmt: off
    component=("Component to train", "positional", None, str, SUPPORTED_COMPONENTS),
    datasets=("Dataset(s) to train", "positional", None, split_string),
    spacy_model=("Base model or blank:lang (e.g. blank:en) for blank model", "positional", None, str),
    init_tok2vec=("Optional path to pretrained weights for the token-to-vector parts of the model", "option", "t2v", str),
    output=("Optional directory to save trained model", "option", "o", str),
    eval_id=("ID of evaluation dataset", "option", "e", str),
    eval_split=("Portion of examples to split off for evaluation if no eval_id is provided", "option", "es", float),
    n_iter=("Number of iterations", "option", "n", int),
    batch_size=("Training batch size or -1 for 'compounding'", "option", "b", int),
    dropout=("Dropout rate", "option", "d", float),
    factor=("Portion of examples to train on, typically only needed for train curve", "option", "f", float),
    textcat_exclusive=("Textcat: treat classes as mutually exclusive", "flag", "TE", bool),
    ner_missing=("NER: assume unannotated spans are missing values, not outside an entity", "flag", "NM", bool),
    binary=("NER/Parser/Tagger: train from binary accept / reject annotations", "flag", "B", bool),
    silent=("Don't print updates", "flag", "S", bool),
    # fmt: on
)
def train(
    component: str,
    datasets: List[str],
    spacy_model: str,
    init_tok2vec: Optional[Union[str, Path]] = None,
    output: Optional[Union[str, Path]] = None,
    eval_id: Optional[str] = None,
    eval_split: Optional[float] = None,
    n_iter: int = 10,
    batch_size: int = -1,
    dropout: float = 0.2,
    factor: float = 1.0,
    textcat_exclusive: bool = False,
    ner_missing: bool = False,
    binary: bool = False,
    silent: bool = False,
) -> Tuple[Any, Any]:
    """
    Train a model component (NER, text classification, tagger or parser) using
    one or more Prodigy datasets with annotations. The recipe calls into
    spaCy directly and can update an existing model or train a new model
    from scratch.
    """
    log("RECIPE: Starting recipe train", locals())
    fix_random_seed(0)
    _msg = get_msg(no_print=silent)
    _print = (lambda string: None) if silent else print
    cfg = {
        "textcat_exclusive": textcat_exclusive,
        "ner_missing": ner_missing,
        "silent": silent,
        "binary": binary,
    }
    DB = connect()
    with _msg.loading(f"Loading '{spacy_model}'..."):
        if spacy_model.startswith("blank:"):
            nlp = spacy.blank(spacy_model.replace("blank:", ""))
        else:
            nlp = spacy.load(spacy_model)
    _msg.good(f"Loaded model '{spacy_model}'")
    pipe_cfg = {}
    if component == "textcat":
        pipe_cfg["exclusive_classes"] = textcat_exclusive
    if component not in nlp.pipe_names:
        if init_tok2vec:
            pipe_cfg.update(
                read_pretrain_hyper_params(init_tok2vec, component, require=True)
            )
        nlp.add_pipe(nlp.create_pipe(component, config=pipe_cfg), last=True)
        resuming = False
    else:
        resuming = True
    pipe = nlp.get_pipe(component)
    if binary:
        data, labels = get_binary_data(component, datasets)
    else:
        merge_cfg = {**cfg, f"{component}_datasets": datasets}
        data, labels = merge_data(nlp, **merge_cfg)
    if not len(data):
        _msg.fail(
            "Can't train model: no data available",
            f"Make sure you're using the correct dataset(s) and your annotations "
            f"are valid for the component you're training ({component}).",
            exits=1,
        )
    random.shuffle(data)
    for label in labels.get(component, []):
        pipe.add_label(label)
    if eval_id is not None:
        if eval_id not in DB:
            msg.fail(f"Can't find eval set '{eval_id}' in database", exits=1)
        train_data = data
        if binary:
            eval_data, _ = get_binary_data(component, [eval_id])
        else:
            merge_cfg = {**cfg, f"{component}_datasets": [eval_id]}
            eval_data, _ = merge_data(nlp, **merge_cfg)
        data_source = f"from '{eval_id}'"
    else:
        train_data, eval_data, split = train_eval_split(data, eval_split, silent=silent)
        data_source = f"split {split:.0%}"
    _msg.text(f"Using {len(train_data)} train / {len(eval_data)} eval ({data_source})")
    if not len(eval_data):
        _msg.fail(
            "Can't train model: no evaluation data available",
            f"If you're holding back examples for evaluation, make sure your "
            f"training set contains enough examples. If you're using a dedicated "
            f"evaluation set, make sure it contains annotations that are valid "
            f"for the component you're training ({component}).",
            exits=1,
        )
    if factor != 1.0:  # e.g. in train-curve
        _msg.info(f"Using {factor:.0%} of the data (factor {factor})")
        train_data = train_data[: int(len(train_data) * factor)]
    _msg.text(
        f"Component: {component} | Batch size: {'compounding' if batch_size == -1 else batch_size} | "
        f"Dropout: {dropout} | Iterations: {n_iter}"
    )
    disabled = nlp.disable_pipes([p for p in nlp.pipe_names if p != component])
    annot_model = get_annot_model(component, nlp, labels) if binary else None
    component_cfg = {component: pipe_cfg}
    if resuming:
        optimizer = nlp.resume_training(component_cfg=component_cfg)
    else:
        optimizer = nlp.begin_training(component_cfg=component_cfg)
    if init_tok2vec is not None:
        _msg.good(f"Initializing with tok2vec weights {init_tok2vec}")
        _msg.text(" | ".join([f"{k}: {v}" for k, v in pipe_cfg.items()]))
        load_pretrained_tok2vec(pipe, init_tok2vec, require=True)
    batch_size = compounding(1.0, 16.0, 1.001) if batch_size == -1 else batch_size
    best_scores = None
    best_model = None
    # Evaluate on texts to prevent nlp.evaluate from reusing state on the doc
    if not binary:
        eval_data = [(doc.text, annot) for doc, annot in eval_data]
    if binary and annot_model:
        baseline = annot_model.evaluate(eval_data)
    else:
        baseline = nlp.evaluate(eval_data)
    train_printer = printers.train_printer(component, baseline, silent, binary)
    with train_printer as (get_acc, result, summary):
        for i in range(n_iter):
            random.shuffle(train_data)
            losses = {}
            data = tqdm.tqdm(train_data, leave=False, desc=f"{i + 1}")
            for batch in minibatch(data, size=batch_size):
                if binary and annot_model:
                    losses = annot_model.batch_train(
                        batch, batch_size=len(batch), drop=dropout, progress=False
                    )
                else:
                    docs, annots = zip(*batch)
                    nlp.update(docs, annots, drop=dropout, losses=losses)
            with nlp.use_params(optimizer.averages):
                if binary and annot_model:
                    scores = annot_model.evaluate(eval_data)
                else:
                    scores = nlp.evaluate(eval_data)
                if not best_scores or get_acc(scores) > get_acc(best_scores):
                    best_scores = scores
                    if output is not None:
                        best_model = pipe.to_bytes(exclude=["vocab"])
            result(i, losses, scores)
        summary(best_scores)
    if output is not None:
        output_path = Path(output)
        pipe.from_bytes(best_model)
        if disabled:
            disabled.restore()
        nlp.to_disk(output_path)
        _msg.good(f"Saved model: {output_path.resolve()}")
    return best_scores, baseline


@recipe(
    "train-curve",
    # fmt: off
    component=("Component to train", "positional", None, str, SUPPORTED_COMPONENTS),
    datasets=("Dataset(s) to train", "positional", None, split_string) ,
    spacy_model=("Base model or blank:lang, e.g. blank:en", "positional", None, str),
    init_tok2vec=("Optional path to pretrained weights for the token-to-vector parts of the model", "option", "t2v", str),
    eval_id=("ID of evaluation dataset", "option", "e", str),
    eval_split=("Portion of examples to split off for evaluation if no eval_id is provided", "option", "es", float),
    n_iter=("Number of iterations", "option", "n", int),
    batch_size=("Training batch size or -1 for 'compounding'", "option", "b", int),
    dropout=("Dropout rate", "option", "d", float),
    n_samples=("Number of samples to take for train curve", "option", "ns", int),
    textcat_exclusive=("Textcat: treat classes as mutually exclusive", "flag", "TE", bool),
    ner_missing=("NER: assume unannotated spans are missing values, not outside an entity", "flag", "NM", bool),
    binary=("NER/Parser/Tagger: train from binary accept / reject annotations", "flag", "B", bool),
    # fmt: on
)
def train_curve(
    component: str,
    datasets: List[str],
    spacy_model: str,
    init_tok2vec: Optional[Union[Path, str]] = None,
    eval_id: Optional[str] = None,
    eval_split: Optional[float] = None,
    n_iter: int = 10,
    batch_size: int = -1,
    dropout: float = 0.2,
    n_samples: int = 4,
    textcat_exclusive: bool = False,
    ner_missing: bool = False,
    binary: bool = False,
):
    """
    Train a model component (NER, text classification, tagger or parser) with
    different portions of the training examples and print the accuracy figures
    and accuracy improvements with more data. Can be used to get an idea of
    whether more annotations could improve the model. This recipe takes pretty
    much the same arguments as `train`.
    """
    log("RECIPE: Starting recipe train-curve", locals())
    factors = [(i + 1) / n_samples for i in range(n_samples)]
    prev_scores = None
    msg.good(f"Starting with model '{spacy_model}'")
    pcs = ", ".join([f"{fac:.0%}" for fac in factors])
    msg.text(f"Training {n_samples} times with {pcs} of the data")
    with printers.train_curve_printer(component, binary) as result:
        for factor in factors:
            best_scores, baseline = train(
                component,
                datasets,
                spacy_model,
                init_tok2vec=init_tok2vec,
                eval_id=eval_id,
                eval_split=eval_split,
                n_iter=n_iter,
                batch_size=batch_size,
                dropout=dropout,
                textcat_exclusive=textcat_exclusive,
                ner_missing=ner_missing,
                binary=binary,
                factor=factor,
                silent=True,
            )
            if not prev_scores:
                prev_scores = baseline
            result(factor, best_scores, prev_scores)
            prev_scores = best_scores


@recipe(
    "data-to-spacy",
    # fmt: off
    output=("Path to output file", "positional", None, str),
    eval_output=("Optional output file for eval examples", "positional", None, str),
    lang=("Language to use for tokenization", "option", "l", str),
    ner=("Comma-separated NER datasets", "option", "n", split_string),
    textcat=("Comma-separated text classification datasets", "option", "tc", split_string),
    tagger=("Comma-separated POS tagging datasets", "option", "t", split_string),
    parser=("Comma-separated dependency parsing datasets", "option", "p", split_string),
    textcat_exclusive=("Textcat: treat classes as mutually exclusive", "flag", "TE", bool),
    ner_missing=("NER: assume unannotated spans are missing values, not outside an entity", "flag", "NM", bool),
    eval_split=("Portion of examples to split off for evaluation if eval_putput is provided", "option", "es", float),
    base_model=("Optional base model to use for tokenization and sentence segmentation", "option", "m", str),
    # fmt: on
)
def data_to_spacy(
    output: Union[str, Path],
    eval_output: Optional[Union[str, Path]] = None,
    lang: str = "en",
    ner: Sequence[str] = tuple(),
    textcat: Sequence[str] = tuple(),
    tagger: Sequence[str] = tuple(),
    parser: Sequence[str] = tuple(),
    textcat_exclusive: bool = False,
    ner_missing: bool = False,
    eval_split: Optional[float] = None,
    base_model: Optional[str] = None,
):
    """
    Combine multiple datasets, merge annotations on the same examples and output
    a file in spaCy's JSON training format that you can use with `spacy train`.
    It's recommended to use the review recipe on the different annotation types
    first to resolve conflicts properly (instead of relying on this recipe to
    just filter conflicting annotations and decide on one).
    """
    log("RECIPE: Starting recipe data-to-spacy", locals())
    fix_random_seed(0)
    if base_model is not None:
        msg.info(f"Starting with base model '{base_model}'")
        nlp = spacy.load(base_model)
    else:
        msg.info(f"Starting with language {lang}")
        nlp = spacy.blank(lang)
        nlp.add_pipe(nlp.create_pipe("sentencizer"))
    cfg = {
        "textcat_exclusive": textcat_exclusive,
        "ner_missing": ner_missing,
        "verbose": True,
    }
    data_tuples, _ = merge_data(nlp, ner, textcat, tagger, parser, **cfg)
    docs = []
    no_ents = []
    for i, (doc, eg) in enumerate(data_tuples):
        if "entities" in eg:
            doc.ents = spans_from_biluo_tags(doc, eg["entities"])
        else:
            # For fixup to remove "ner" if docs didn't have NER annotations
            # (even if doc.ents are not set, docs_to_json still adds the tags)
            no_ents.append(i)
        if "cats" in eg:
            doc.cats = eg["cats"]
        if "tags" in eg:
            for idx, tag in enumerate(eg["tags"]):
                if tag is not None:
                    doc[idx].tag_ = tag
            doc.is_tagged = True
        if "deps" in eg and "heads" in eg:
            for idx, head in enumerate(eg["heads"]):
                doc[idx].head = doc[head]
            for idx, dep in enumerate(eg["deps"]):
                if dep is not None:
                    doc[idx].dep_ = dep
            doc.is_parsed = True
        docs.append((i, doc))
    json_data = [docs_to_json([doc], id=i) for i, doc in docs]
    if ner_missing or no_ents:
        json_data = _fix_up_ner(json_data, ner_missing=ner_missing, no_ents=no_ents)
    if eval_output:
        random.shuffle(json_data)
        json_data, eval_data, split = train_eval_split(json_data, eval_split)
        msg.text(
            f"Using {len(json_data)} train / {len(eval_data)} eval (split {split:.0%})"
        )
        srsly.write_json(eval_output, eval_data)
        msg.good(f"Saved {len(eval_data)} examples to {eval_output}")
    srsly.write_json(output, json_data)
    msg.good(f"Saved {len(json_data)} examples to {output}")


def merge_data(
    nlp: spacy.language.Language,
    ner_datasets: Sequence[str] = tuple(),
    textcat_datasets: Sequence[str] = tuple(),
    tagger_datasets: Sequence[str] = tuple(),
    parser_datasets: Sequence[str] = tuple(),
    textcat_exclusive: bool = False,
    ner_missing: bool = False,
    binary: bool = False,
    silent: bool = False,
    verbose: bool = False,
) -> Tuple[List[Tuple[spacy.tokens.Doc, dict]], Dict[str, Set[str]]]:
    DB = connect()
    validate = get_config().get("validate", True)
    texts_by_input = {}
    labels = defaultdict(set)
    stats = []

    # Named Entity Recognition
    ner_by_input = {}
    ner_examples = load_examples(DB, ner_datasets)
    for eg in validate_examples(ner_examples, "ner", active=validate):
        if eg.get("answer", "accept") != "accept":
            continue
        input_hash = eg[INPUT_HASH_ATTR]
        texts_by_input.setdefault(input_hash, eg.get("text"))
        ner_by_input.setdefault(input_hash, [])
        for span in eg.get("spans", []):
            if span.get("answer", "accept") == "accept":
                offsets = (span["start"], span["end"], span["label"])
                ner_by_input[input_hash].append(offsets)
                labels["ner"].add(span["label"])
    for key, offsets in ner_by_input.items():
        ner_by_input[key] = filter_offsets(offsets)
    if ner_examples:
        stats.append(("NER", len(ner_examples), len(ner_by_input)))

    # Text Classification
    textcat_by_input = {}
    textcat_examples = load_examples(DB, textcat_datasets)
    textcat_validated = validate_examples(textcat_examples, "textcat", active=validate)
    for eg in convert_options_to_cats(textcat_validated, exclusive=textcat_exclusive):
        input_hash = eg[INPUT_HASH_ATTR]
        texts_by_input.setdefault(input_hash, eg.get("text"))
        textcat_by_input.setdefault(input_hash, {})
        cats = eg.get("cats", {})
        textcat_by_input[input_hash].update(cats)
        labels["textcat"].update(cats)
    if textcat_examples:
        stats.append(("Textcat", len(textcat_examples), len(textcat_by_input)))

    # Part-of-speech tags
    pos_by_input = {}
    pos_examples = load_examples(DB, tagger_datasets)
    for eg in validate_examples(pos_examples, "tagger", active=validate):
        input_hash = eg[INPUT_HASH_ATTR]
        n_tokens = len(eg.get("tokens", []))
        if not n_tokens or eg.get("answer", "accept") != "accept":
            continue
        texts_by_input.setdefault(input_hash, eg.get("text"))
        pos_by_input.setdefault(input_hash, [None for i in range(n_tokens)])
        for span in eg.get("spans", []):
            not_accept = span.get("answer", "accept") != "accept"
            no_tokens = "token_start" not in span or "token_end" not in span
            # Continue if span has more than 1 token (note off-by-one)
            too_long = span["token_start"] != span["token_end"]
            mismatch = span["token_start"] >= len(pos_by_input[input_hash])
            if not_accept or no_tokens or too_long or mismatch:
                continue
            pos_by_input[input_hash][span["token_start"]] = span["label"]
            labels["tagger"].add(span["label"])
    if pos_examples:
        stats.append(("Tagger", len(pos_examples), len(pos_by_input)))

    # Dependencies
    dep_by_input = {}
    heads_by_input = {}
    dep_examples = load_examples(DB, parser_datasets)
    for eg in validate_examples(dep_examples, "parser", active=validate):
        input_hash = eg[INPUT_HASH_ATTR]
        n_tokens = len(eg.get("tokens", []))
        arcs = eg.get("relations", eg.get("arcs", []))
        if not n_tokens or eg.get("answer") != "accept" or len(arcs) == 0:
            continue
        texts_by_input.setdefault(input_hash, eg.get("text"))
        heads_by_input.setdefault(input_hash, [i for i in range(n_tokens)])
        dep_by_input.setdefault(input_hash, [None for i in range(n_tokens)])
        for arc in arcs:
            if arc["head"] >= n_tokens or arc["child"] >= n_tokens:
                continue
            heads_by_input[input_hash][arc["child"]] = arc["head"]
            dep_by_input[input_hash][arc["child"]] = arc["label"]
            labels["parser"].add(arc["label"])
    if dep_examples:
        stats.append(("Parser", len(dep_examples), len(dep_by_input)))

    result = []
    missing_tag = "-" if ner_missing else "O"
    n_skipped_ents = 0
    n_skipped_tags = 0
    n_skipped_deps = 0
    input_tuples = ((text, input_hash) for input_hash, text in texts_by_input.items())
    with nlp.disable_pipes([p for p in nlp.pipe_names if p != "sentencizer"]):
        for doc, input_hash in nlp.pipe(input_tuples, as_tuples=True):
            eg = {}
            if input_hash in ner_by_input:
                offsets = ner_by_input[input_hash]
                try:
                    biluo = biluo_tags_from_offsets(doc, offsets, missing=missing_tag)
                    eg["entities"] = biluo
                except ValueError:
                    n_skipped_ents += len(offsets)
            if input_hash in textcat_by_input:
                cats = textcat_by_input[input_hash]
                for label in labels["textcat"]:
                    if label not in cats:
                        cats[label] = 0.0
                eg["cats"] = cats
            if input_hash in pos_by_input:
                tags = pos_by_input[input_hash]
                if len(doc) == len(tags):
                    eg["tags"] = tags
                else:
                    n_skipped_tags += len(tags)
            if input_hash in dep_by_input:
                deps = dep_by_input[input_hash]
                if len(doc) == len(deps):
                    eg["deps"] = deps
                else:
                    n_skipped_deps += len(deps)
            if input_hash in heads_by_input:
                heads = heads_by_input[input_hash]
                if len(doc) == len(heads):
                    eg["heads"] = heads
            result.append((doc, eg))

    if not silent:
        msg.text(f"Created and merged data for {len(texts_by_input)} total examples")
        if n_skipped_ents:
            msg.warn(f"Skipped {n_skipped_ents} entity spans (mismatched tokenization)")
        if n_skipped_tags:
            msg.warn(f"Skipped {n_skipped_tags} POS tags (mismatched tokenization)")
        if n_skipped_deps:
            msg.warn(f"Skipped {n_skipped_deps} dependencies (mismatched tokenization)")
        if verbose:
            header = ["Type", "Total", "Merged"]
            msg.table(stats, header=header, aligns=("l", "r", "r"), divider=True)

    return result, labels


def _fix_up_ner(json_data, ner_missing, no_ents):
    # 1. Handle missing values (replace when docs.to_json supports missing flag)
    # 2. Remove "ner" if doc didn't have entity annotations
    for doc in json_data:
        for para in doc["paragraphs"]:
            for sent in para["sentences"]:
                for token in sent["tokens"]:
                    fixup_missing = ner_missing and token["ner"] == "0"
                    if "ner" in token and (fixup_missing or doc["id"] in no_ents):
                        del token["ner"]
    return json_data


def get_binary_data(component, datasets):
    DB = connect()
    validate = get_config().get("validate", True)
    labels = set()
    data = []
    examples = load_examples(DB, datasets)
    for eg in validate_examples(examples, component, active=validate):
        if eg.get("answer") != "ignore":
            spans = eg.get("arcs" if component == "dep" else "spans", [])
            for span in spans:
                labels.add(span["label"])
            data.append(eg)
    if component == "ner":
        data = merge_spans(data)
    elif component == "tagger":
        data = merge_tags(data)
    elif component == "parser":
        data = merge_arcs(data)
    return data, {component: labels}


def load_examples(db, datasets=tuple()):
    result = []
    for set_id in datasets:
        if set_id not in db:
            msg.fail(f"Can't find '{set_id}' in database '{db.db_name}'", exits=1)
        examples = db.get_dataset(set_id) or []
        for eg in examples:
            if eg.get("answer") != "ignore":
                result.append(set_hashes(eg, overwrite=True))
    return result


def train_eval_split(examples, eval_split=None, threshold=1000, silent=False):
    if eval_split is None and len(examples) < threshold:
        eval_split = 0.5
    elif eval_split is None:
        eval_split = 0.2
    elif eval_split == 1.0:
        return examples, list(examples), eval_split
    evals = examples[: int(len(examples) * eval_split)]
    examples = examples[len(evals) :]
    return examples, evals, eval_split


def get_annot_model(component, nlp, label, **kwargs):
    label = label.get(component, [])
    # Only used for binary annotations: get annotation model
    if component == "ner":
        return AnnotationModels.EntityRecognizer(nlp, label=label, no_missing=True)
    if component == "parser":
        return AnnotationModels.DependencyParser(nlp, label=label)
    if component == "tagger":
        return AnnotationModels.Tagger(nlp, label=label)
    msg.fail(
        f"Setting --binary is not supported for component '{component}'",
        "Just use the regular training process instead.",
        exits=1,
    )


def validate_examples(examples, component, active=True):
    schemas = {
        "ner": NerExample,
        "textcat": TextcatExample,
        "tagger": PosExample,
        "parser": DepExample,
    }
    error_msg = f"Invalid data for component '{component}'"
    schema = schemas[component]
    for eg in examples:
        if active:
            validate(schema, eg, error_msg=error_msg)
        yield eg
