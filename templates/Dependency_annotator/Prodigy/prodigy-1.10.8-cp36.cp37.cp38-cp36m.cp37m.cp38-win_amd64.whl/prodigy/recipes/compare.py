from typing import Union, Dict, Any, Iterable, Callable
from pathlib import Path
from collections import Counter
import random
import srsly

from ..core import recipe
from ..util import log, msg


@recipe(
    "compare",
    # fmt: off
    dataset=("Dataset to save annotations to", "positional", None, str),
    a_file=("JSONL file for system responses", "positional", None, str),
    b_file=("JSONL file for baseline responses", "positional", None, str),
    no_random=("Don't randomize which annotation is shown as correct", "flag", "NR", bool),
    diff=("Show examples as visual diff", "flag", "D", bool),
    # fmt: on
)
def compare(
    dataset: str,
    a_file: Union[str, Path],
    b_file: Union[str, Path],
    no_random: bool = False,
    diff: bool = False,
) -> Dict[str, Any]:
    """
    Compare output of two models and randomly assign A/B categories.
    """
    log("RECIPE: Starting recipe compare", locals())
    a_questions = srsly.read_jsonl(a_file)
    b_questions = srsly.read_jsonl(b_file)
    stream = get_questions(a_questions, b_questions, not no_random, diff)
    on_exit = get_printer(Path(a_file).name, Path(b_file).name)

    return {
        "dataset": dataset,
        "view_id": "diff" if diff is True else "choice",
        "stream": stream,
        "progress": None,
        "on_exit": on_exit,
        "config": {
            "auto_exclude_current": False,
            "choice_auto_accept": True,
            "force_stream_order": True,
        },
    }


def get_questions(
    a_questions: Dict[str, Any],
    b_questions: Dict[str, Any],
    randomize: bool = False,
    diff: bool = False,
) -> Iterable[dict]:
    a_questions = {a["id"]: a for a in a_questions}
    b_questions = {b["id"]: b for b in b_questions}
    for id_, a in a_questions.items():
        if id_ not in b_questions:
            continue
        question = {
            "id": id_,
            "input": a["input"],
            "A": a["output"],
            "B": b_questions[id_]["output"],
        }
        if question["A"] == question["B"]:
            continue
        if randomize and random.random() >= 0.5:
            question["mapping"] = {"B": "accept", "A": "reject"}
        else:
            question["mapping"] = {"A": "accept", "B": "reject"}
        # Add options for choice interface
        question["options"] = []
        for key, answer in question["mapping"].items():
            option = question[key]
            option["id"] = key
            question["options"].append(option)
            if diff:
                question[answer] = option
        yield question


def get_printer(a_file_name: str, b_file_name: str) -> Callable:
    filenames = {"A": a_file_name, "B": b_file_name}

    def _format_printer(ctrl):
        examples = ctrl.db.get_dataset(ctrl.dataset)
        counts = Counter()
        answers = {}
        # Get last example per ID
        for eg in examples:
            if "answer" not in eg or "mapping" not in eg:
                continue
            if "reject" not in eg:  # task created with choice UI
                selected = eg.get("accept", [])
                if not selected or len(selected) != 1 or eg["answer"] != "accept":
                    continue
                eg["answer"] = eg["mapping"].get(selected[0])
            answers[eg["id"]] = (eg["answer"], eg["mapping"])
        for answer, mapping in answers.values():
            if answer == "ignore":
                counts["ignore"] += 1
            else:
                inverse = {v: k for k, v in mapping.items()}
                answer = inverse[answer]
                counts[answer] += 1
        print("")
        log(f"RECIPE: Calculating results with counts {counts}")
        if not counts:
            msg.warn("No answers found", exits=0)
        msg.divider("Evaluation results", icon="emoji")
        pref, _ = counts.most_common(1)[0]
        if counts["A"] == counts["B"]:
            msg.info("You had no preference")
            pref = None
        else:
            msg.good(f"You preferred {pref} ({filenames.get(pref)})")
        rows = [
            ("A", counts["A"], filenames.get("A")),
            ("B", counts["B"], filenames.get("B")),
            ("Ignored", counts["ignore"], ""),
            ("Total", sum(counts.values()), ""),
        ]
        msg.table(rows, aligns=("l", "r", "l"))

    return _format_printer
