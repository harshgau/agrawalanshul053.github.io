from typing import List, Optional, Union, Iterable, Dict, Any

from ..components.loaders import get_stream
from ..components.preprocess import fetch_media
from ..core import recipe
from ..util import log, get_labels, split_string, msg


@recipe(
    "image.manual",
    # fmt: off
    dataset=("Dataset to save annotations to", "positional", None, str),
    source=("Data to annotate (directory of images, file path or '-' to read from standard input)", "positional", None, str),
    loader=("Loader if source is not directory of images", "option", "lo", str),
    label=("Comma-separated label(s) to annotate or text file with one label per line", "option", "l", get_labels),
    exclude=("Comma-separated list of dataset IDs whose annotations to exclude", "option", "e", split_string),
    darken=("Darken image to make boxes stand out more", "flag", "D", bool),
    width=("Default width of the annotation card and space for the image (in px)", "option", "w", int),
    no_fetch=("Don't fetch images as base64", "flag", "NF", bool),
    remove_base64=("Remove base64-encoded image data before storing example in the DB. (Caution: if enabled, make sure to keep original files!)", "flag", "R", bool)
    # fmt: on
)
def image_manual(
    dataset: str,
    source: Union[str, Iterable[dict]],
    loader: str = "images",
    label: Optional[List[str]] = None,
    exclude: Optional[List[str]] = None,
    darken: bool = False,
    width: int = 675,
    no_fetch: bool = False,
    remove_base64: bool = False,
) -> Dict[str, Any]:
    """
    Manually annotate images by drawing rectangular bounding boxes or polygon
    shapes on the image.
    """
    log("RECIPE: Starting recipe image.manual", locals())
    if label is None:
        msg.fail("The --label argument (one or more labels) is required", exits=1)
    stream = get_stream(source, loader=loader, input_key="image")
    if not no_fetch and loader != "image-server":
        stream = fetch_media(stream, ["image"])

    def before_db(examples):
        # Remove all data URIs before storing example in the database
        for eg in examples:
            if eg["image"].startswith("data:"):
                eg["image"] = eg.get("path")
        return examples

    return {
        "view_id": "image_manual",
        "dataset": dataset,
        "stream": stream,
        "before_db": before_db if remove_base64 else None,
        "exclude": exclude,
        "config": {
            "labels": label,
            "darken_image": 0.3 if darken else 0,
            "custom_theme": {"cardMaxWidth": width},
            "exclude_by": "input",
            "force_stream_order": True,
        },
    }
