from typing import List, Optional, Union, Iterable, Dict, Any

from ..core import recipe
from ..components.loaders import get_stream
from ..components.preprocess import fetch_media as fetch_media_preprocessor
from ..util import log, msg, get_labels, split_string


def remove_base64(examples):
    """Remove base64-encoded string if "path" is preserved in example."""
    for eg in examples:
        if "audio" in eg and eg["audio"].startswith("data:") and "path" in eg:
            eg["audio"] = eg["path"]
        if "video" in eg and eg["video"].startswith("data:") and "path" in eg:
            eg["video"] = eg["path"]
    return examples


@recipe(
    "audio.manual",
    # fmt: off
    dataset=("Dataset to save annotations to", "positional", None, str),
    source=("Data to annotate (file path or '-' to read from standard input)", "positional", None, str),
    loader=("Loader to use", "option", "lo", str),
    label=("Comma-separated label(s) to annotate or text file with one label per line", "option", "l", get_labels),
    keep_base64=("If 'audio' loader is used: don't remove base64-encoded data from the data on save", "flag", "B", bool),
    autoplay=("Autoplay audio when a new task loads", "flag", "A", bool),
    fetch_media=("Convert URLs and local paths to data URIs", "flag", "FM", bool),
    exclude=("Comma-separated list of dataset IDs whose annotations to exclude", "option", "e", split_string),
    # fmt: on
)
def manual(
    dataset: str,
    source: Union[str, Iterable[dict]],
    loader: Optional[str] = "audio",
    label: Optional[List[str]] = None,
    autoplay: bool = False,
    keep_base64: bool = False,
    fetch_media: bool = False,
    exclude: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Stream in audio or video files and manually label regions for the given
    labels. Uses the 'audio' loader by default, which encodes the data as base64
    (and removes it from the task afterwards, unless you set --keep-base64).
    Alternatively, you can also use the loaders 'audio-server', 'video',
    'video-server' or 'jsonl' (to stream in pre-formatted data from JSONL).
    """
    log("RECIPE: Starting recipe audio.manual", locals())
    if label is None:
        msg.fail("audio.manual requires at least one --label", exits=1)
    stream = get_stream(source, loader=loader, dedup=True, rehash=True)
    if fetch_media:
        stream = fetch_media_preprocessor(stream, ["audio", "video"])

    return {
        "view_id": "audio_manual",
        "dataset": dataset,
        "stream": stream,
        "before_db": remove_base64 if not keep_base64 else None,
        "exclude": exclude,
        "config": {
            "labels": label,
            "audio_autoplay": autoplay,
            "force_stream_order": True,
        },
    }


@recipe(
    "audio.transcribe",
    # fmt: off
    dataset=("Dataset to save annotations to", "positional", None, str),
    source=("Data to annotate (file path or '-' to read from standard input)", "positional", None, str),
    loader=("Loader to use", "option", "lo", str),
    playpause_key=("Keyboard shortcuts to toggle play/pause to prevent conflict with text input", "option", "pk", split_string),
    text_rows=("Height of text field in rows", "option", "tr", int),
    field_id=("Add the transcript text to the data using this key", "option", "fi", str),
    keep_base64=("If 'audio' loader is used: don't remove base64-encoded data from the data on save", "flag", "B", bool),
    autoplay=("Autoplay audio when a new task loads", "flag", "A", bool),
    fetch_media=("Convert URLs and local paths to data URIs", "flag", "FM", bool),
    exclude=("Comma-separated list of dataset IDs whose annotations to exclude", "option", "e", split_string),
    # fmt: on
)
def transcribe(
    dataset: str,
    source: Union[str, Iterable[dict]],
    loader: Optional[str] = "audio",
    playpause_key: List[str] = ["command+enter", "option+enter", "ctrl+enter"],
    text_rows: int = 4,
    field_id: str = "transcript",
    autoplay: bool = False,
    keep_base64: bool = False,
    fetch_media: bool = False,
    exclude: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Stream in audio or video files and transcribe them in a text box. Uses the
    'audio' loader by default, which encodes the data as base64 (and removes it
    from the task afterwards, unless you set --keep-base64). The created
    transcript will be added as the key "transcript". To prevent the default
    play/pause key (enter) from clashing with the text input field, the
    --playpause-key setting lets you specify comma-separated options
    (default: enter + command/option/alt/ctrl).
    """
    log("RECIPE: Starting recipe audio.transcribe", locals())
    stream = get_stream(source, loader=loader, dedup=True, rehash=True)
    if fetch_media:
        stream = fetch_media_preprocessor(stream, ["audio", "video"])

    blocks = [
        {"view_id": "audio"},
        {
            "view_id": "text_input",
            "field_rows": text_rows,
            "field_label": "Transcript",
            "field_id": field_id,
            "field_autofocus": True,
        },
    ]
    return {
        "view_id": "blocks",
        "dataset": dataset,
        "stream": stream,
        "before_db": remove_base64 if not keep_base64 else None,
        "exclude": exclude,
        "config": {
            "blocks": blocks,
            "audio_autoplay": autoplay,
            "keymap": {"playpause": playpause_key},
            "force_stream_order": True,
        },
    }
