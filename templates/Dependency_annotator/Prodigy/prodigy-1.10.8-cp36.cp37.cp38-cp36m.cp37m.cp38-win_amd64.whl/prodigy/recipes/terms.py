from typing import Optional, Dict, Any, Set
import spacy
import srsly
from spacy.tokens import Doc
from pathlib import Path

from ..core import recipe
from ..components.db import connect
from ..components.sorters import Probability
from ..util import read_txt, set_hashes, log, msg


def get_seeds(seed_data: str) -> Set[str]:
    """Create a set of seed terms from string or path. Used as a helper to
    resolve the command line input of the `--seeds` argument to a set of terms.

    seed_data (unicode): The seed terms, either a string, string path or None.
    RETURNS (set): A set of seed terms.
    """
    if not seed_data:
        msg.info("Initializing with no seed terms")
        return set()
    seed_path = Path(seed_data)
    if seed_path.is_file():
        seed_terms = [s for s in read_txt(seed_path) if s != ""]
        msg.info(f"Initializing with {len(seed_terms)} seed terms from {seed_path}")
        return set(seed_terms)
    seed_terms = set([t.strip() for t in seed_data.split(",") if t != ""])
    msg.info(f"Initializing with {len(seed_terms)} seed terms", ", ".join(seed_terms))
    return seed_terms


@recipe(
    "terms.teach",
    # fmt: off
    dataset=("Dataset to save annotations to", "positional", None, str),
    vectors=("Loadable spaCy model with word vectors, e.g. en_vectors_web_lg", "positional", None, str),
    seeds=("Comma-separated seed terms or file with one term per line", "option", "se", str),
    resume=("Resume from existing terms dataset and update target vector accordingly", "flag", "R", bool),
    # fmt: on
)
def teach(
    dataset: str, vectors: str, seeds: Optional[str] = None, resume: bool = False
) -> Dict[str, Any]:
    """
    Bootstrap Prodigy with word vectors and seeds. Seeds can either be a
    path to a newline-separated text file, or a string with comma-separated
    terms.
    """
    log("RECIPE: Starting recipe terms.teach", locals())
    DB = connect()
    seeds = get_seeds(seeds)
    seed_tasks = [set_hashes({"text": s, "answer": "accept"}) for s in seeds]
    DB.add_examples(seed_tasks, datasets=[dataset])
    nlp = spacy.load(vectors)
    # add all words with vectors to lexeme cache
    for s in nlp.vocab.vectors:
        nlp.vocab[s]
    log(f"RECIPE: Loaded vectors from {vectors}")
    accept_words = seeds
    reject_words = set()
    if resume:
        prev = DB.get_dataset(dataset)
        prev_accept = [eg["text"] for eg in prev if eg["answer"] == "accept"]
        prev_reject = [eg["text"] for eg in prev if eg["answer"] == "reject"]
        total = len(prev_accept) + len(prev_reject)
        msg.text(f"Updating target vector with {total} terms from dataset '{dataset}'")
        accept_words.update(prev_accept)
        reject_words.update(prev_reject)
    accept_doc = Doc(nlp.vocab, words=accept_words)
    reject_doc = Doc(nlp.vocab, words=reject_words)
    score = 0

    def predict(term):
        nonlocal accept_doc, reject_doc
        if len(accept_doc) == 0 and len(reject_doc) == 0:
            return 0.5
        if len(accept_doc) and accept_doc.vector_norm != 0.0:
            accept_score = max(term.similarity(accept_doc), 0.0)
        else:
            accept_score = 0.0
        if len(reject_doc) and reject_doc.vector_norm != 0:
            reject_score = max(term.similarity(reject_doc), 0.0)
        else:
            reject_score = 0.0
        score = accept_score / (accept_score + reject_score + 0.2)
        return max(score, 0.0)

    def update(answers):
        nonlocal accept_doc, reject_doc, score
        log(f"RECIPE: Update predictions with {len(answers)} answers", answers)
        accept_words = [t.text for t in accept_doc]
        reject_words = [t.text for t in reject_doc]
        for answer in answers:
            if answer["answer"] == "accept":
                score += 1
                accept_words.append(answer["text"])
            elif answer["answer"] == "reject":
                score -= 1
                reject_words.append(answer["text"])
        accept_doc = Doc(nlp.vocab, words=accept_words)
        reject_doc = Doc(nlp.vocab, words=reject_words)

    def stream_scored(stream):
        lexemes = [lex for lex in stream if lex.is_alpha and lex.is_lower]
        while True:
            seen = set(w.orth for w in accept_doc)
            seen.update(set(w.orth for w in reject_doc))
            lexemes = [w for w in lexemes if w.orth not in seen and w.vector_norm]
            by_score = [(predict(lex), lex) for lex in lexemes]
            by_score.sort(reverse=True)
            for _, term in by_score:  # Need to predict in loop, as model changes
                score = predict(term)
                yield score, {"text": term.text, "meta": {"score": score}}

    stream = Probability(stream_scored(nlp.vocab))

    return {
        "dataset": dataset,
        "view_id": "text",
        "stream": stream,
        "update": update,
    }


@recipe(
    "terms.to-patterns",
    # fmt: off
    dataset=("Terms dataset to convert to patterns", "positional", None, str),
    label=("Label to assign to the patterns", "option", "l", str),
    output_file=("Optional output file", "positional", None, str),
    spacy_model=("spaCy model for tokenization or blank:lang (e.g. blank:en)", "option", "m", str),
    case_sensitive=("Make token patterns case sensitive", "flag", "CS", bool),
    # fmt: on
)
def to_patterns(
    dataset: str,
    label: Optional[str] = None,
    output_file: Optional[str] = None,
    spacy_model: Optional[str] = None,
    case_sensitive: bool = False,
):
    """
    Convert a list of seed terms to a list of match patterns that can be used
    with recipes that take a --patterns argument, like ner.manual or match.
    """
    log("RECIPE: Starting recipe terms.to-patterns", locals())
    if label is None:
        err = "This is the label that will be assigned to all patterns."
        msg.fail("--label is a required argument", err, exits=1)
    if spacy_model is None:
        nlp = None
    elif spacy_model.startswith("blank:"):
        nlp = spacy.blank(spacy_model.replace("blank:", ""))
    else:
        nlp = spacy.load(spacy_model)

    def get_pattern(term, label):
        if nlp is not None:
            if case_sensitive:
                pattern = [{"text": t.text} for t in nlp.make_doc(term)]
            else:
                pattern = [{"lower": t.lower_} for t in nlp.make_doc(term)]
        else:
            pattern = term
        return {"label": label, "pattern": pattern}

    DB = connect()
    if dataset not in DB:
        msg.fail(f"Can't find dataset '{dataset}'", exits=1)
    examples = DB.get_dataset(dataset)
    terms = [eg.get("word", eg["text"]) for eg in examples if eg["answer"] == "accept"]
    log(f"RECIPE: Reading {len(terms)} input terms from '{dataset}'")
    if output_file:
        patterns = [get_pattern(term, label) for term in terms]
        log(f"RECIPE: Generated {len(patterns)} patterns")
        srsly.write_jsonl(output_file, patterns)
        msg.good(f"Exported {len(patterns)} patterns", output_file)
    else:
        for term in terms:
            print(srsly.json_dumps(get_pattern(term, label)))
