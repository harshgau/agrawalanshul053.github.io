# coding: utf8
from __future__ import unicode_literals

from ..deprecated import recipes  # noqa
from . import dep, ner, textcat, pos, compare, terms, generic, image, rel, coref  # noqa
from . import audio, review, train, commands  # noqa
