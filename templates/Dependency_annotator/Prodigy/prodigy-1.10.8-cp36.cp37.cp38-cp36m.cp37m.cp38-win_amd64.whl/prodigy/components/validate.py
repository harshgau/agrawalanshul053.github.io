from pydantic import ValidationError
import sys
import copy

from ..types import TextTask, ClassificationTask, ImageTask, SpansTask, SpansManualTask
from ..types import DepTask, HtmlTask, CompareTask, DiffTask, ChoiceTask
from ..types import ReviewTask, TextInputTask, BlocksTask, AudioTask, RelationsTask
from ..types import Config, RecipeComponents
from ..util import log, msg


SCHEMAS = {
    "text": TextTask,
    "classification": ClassificationTask,
    "spans": SpansTask,
    "spans_manual": SpansManualTask,
    "ner": SpansTask,
    "ner_manual": SpansManualTask,
    "pos": SpansTask,
    "pos_manual": SpansManualTask,
    "dep": DepTask,
    "image": ImageTask,
    "image_manual": ImageTask,
    "html": HtmlTask,
    "compare": CompareTask,
    "diff": DiffTask,
    "choice": ChoiceTask,
    "review": ReviewTask,
    "text_input": TextInputTask,
    "blocks": BlocksTask,
    "audio": AudioTask,
    "audio_manual": AudioTask,
    "relations": RelationsTask,
}


def get_schema(view_id, json=True):
    """Get the schema for a given view ID (called by Validator or the user).

    view_id (unicode): The view ID to get the schema for.
    json (bool): Return schema as JSON schema instead of pydantic model.
    RETURNS (dict): The JSON schema.
    """
    if view_id not in SCHEMAS:
        opts = ", ".join(SCHEMAS.keys())
        msg.fail(f"Not a valid view ID: '{view_id}'", f"Available: {opts}", exits=1)
    schema = SCHEMAS[view_id]
    if json:
        return schema.schema_json()
    return schema


def validate_config(config):
    log("VALIDATE: Validating Prodigy and recipe config")
    error_msg = "Invalid settings found in prodigy.json and/or recipe config"
    validate(Config, config, error_msg=error_msg, print_obj=False)


def validate_recipe(name, components):
    log("VALIDATE: Validating components returned by recipe")
    error_msg = f"Invalid components returned by recipe '{name}'"
    validate(RecipeComponents, components, error_msg=error_msg)


def validate(Schema, obj, error_msg="Validation error", print_obj=True):
    """Validate a JSON object with a given schema.

    Schema (pydantic.BaseModel): The pydantic model to check against.
    obj (dict): The object to validate.
    error_msg (str): Optional custom error message to show.
    print_obj (bool): Whether to also print the object on error.
    """
    try:
        Schema(**obj)
    except ValidationError as e:
        errors = e.errors()
        if errors:
            msg.fail(error_msg)
            data = []
            for error in errors:
                err_loc = " -> ".join([str(p) for p in error.get("loc", [])])
                data.append((err_loc, error.get("msg")))
            msg.table(data)
            if print_obj:
                print(format_obj(obj))
        sys.exit(1)


def format_obj(obj, keys=("text", "image", "audio", "video"), max_length=200):
    """Reformat task dict with base64 keys to not clog up the terminal."""
    try:
        obj = copy.deepcopy(obj)
    except TypeError:
        return obj
    for key in keys:
        if key in obj and isinstance(obj[key], str) and len(obj[key]) > 200:
            obj[key] = f"{obj[key][:200]}..."
    return obj


class Validator(object):
    """Validate incoming tasks against JSON schemas."""

    def __init__(self, view_id):
        log(f"VALIDATE: Creating validator for view ID '{view_id}'")
        self.view_id = view_id
        self.Schema = get_schema(view_id, json=False)
        self.error_msg = f"Invalid task format for view ID '{self.view_id}'"

    def check(self, obj):
        """Check a task and raise an error if it's not valid.

        obj (dict): The task to validate.
        """
        validate(self.Schema, obj, error_msg=self.error_msg)

    def is_valid(self, obj):
        """
        obj (dict): The task to check.
        RETURNS (bool): Whether the task is valid.
        """
        try:
            self.Schema(**obj)
            return True
        except ValidationError:
            return False
