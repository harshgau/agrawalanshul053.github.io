from .util import init_package

init_package()

import shlex

from . import recipes
from .about import __version__
from .components.loaders import get_stream, get_loader
from .components.validate import get_schema
from .core import recipe, get_recipe, set_recipe
from .util import get_config, set_hashes, log, msg
from .deprecated.core import recipe_args
from .app import server


def serve(command, *recipe_args, **config):
    """Start the Prodigy server from Python. Currently supports two usage
    patterns for backwards-compatibility:

    1. Old usage: pass in recipe name and all recipe args in order (positional).
    2. New usage: pass in string command in the same format as the command
       used on the command line (without "prodigy").

    command (str): Full string command or recipe name (old usage).
    *recipe_args: Positional recipe arguments (old usage only).
    **config: Config settings to overwrite Prodigy config.
    """
    cli_args = shlex.split(command)
    if len(cli_args) and not recipe_args:
        # New usage pattern
        recipe_name = cli_args.pop(0)
        loaded_recipe = get_recipe(recipe_name)
        if not loaded_recipe:
            msg.fail(f"Can't find recipe '{recipe_name}'", exits=1)
        controller = loaded_recipe(*cli_args, use_plac=True, config=config)
        if not controller:
            msg.fail(
                f"Can't serve '{recipe_name}'. It doesn't seem to be a recipe "
                f"that requires the Prodigy server to be started.",
                exits=1,
            )
        server(controller, controller.config)
    else:
        # Backwards-compatibility: first arg used to be recipe name
        loaded_recipe = get_recipe(command)
        if not loaded_recipe:
            msg.fail(f"Can't find recipe '{recipe_name}'", exits=1)
        controller = loaded_recipe(*recipe_args, config=config)
        server(controller, controller.config)
