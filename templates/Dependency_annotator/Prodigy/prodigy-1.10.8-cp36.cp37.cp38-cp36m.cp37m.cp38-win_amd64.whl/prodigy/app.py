from typing import Optional, List
import os
import jwt
import uuid
import datetime
from pathlib import Path
import threading
import uvicorn
from uvicorn.config import LOGGING_CONFIG as UVICORN_LOGGING_CONFIG
from starlette.staticfiles import StaticFiles
from starlette.responses import HTMLResponse, Response
from starlette.requests import Request
from starlette.middleware.cors import CORSMiddleware
from starlette.status import HTTP_403_FORBIDDEN, HTTP_401_UNAUTHORIZED
from fastapi import Depends, FastAPI, HTTPException, APIRouter
from fastapi.security import HTTPBasic, HTTPBasicCredentials
from fastapi.security.http import HTTPAuthorizationCredentials, HTTPBearer
from pydantic import ValidationError
import srsly
import copy

from .types import APIAnswersRequest, APIVersionResponse, APIQuestionsResponse
from .types import APISessionQuestionsRequest, SessionID, APIAnswersResponse
from .types import APIAnswerValidateRequest, APIAnswerValidateResponse
from .types import JWTPayload, JWTAuthorizationCredentials
from .util import msg, log, get_valid_sessions, get_log_level, ENV_VARS
from . import about
from .components.db import db_state_default, PeeweeConnectionState
import peewee


API_DOCSTRING = "REST endpoints used for interacting with Prodigy tasks"
STATIC_DIR = Path(__file__).parent / "static"
CONFIG = {}
CONTROLLER = None
# The name used for prodigy JWT cookies
JWT_COOKIE_NAME = "_prodigy_"

# Prevent uvicorn from logging our log messages again
_uvicorn_log_config = copy.deepcopy(UVICORN_LOGGING_CONFIG)


def set_controller(controller, config):
    """Prepare a controller/config for hosting the prodigy application and API endpoints"""
    global CONTROLLER, CONFIG
    config["view_id"] = controller.view_id
    config["batch_size"] = controller.batch_size
    config["version"] = about.__version__
    instructions = config.get("instructions")
    if instructions:
        help_path = Path(instructions)
        if not help_path.is_file():
            msg.fail("Can't read instructions", help_path, exits=1)
        with help_path.open("r", encoding="utf8") as f:
            config["instructions"] = f.read()
    for setting in ["db_settings", "api_keys"]:
        if setting in config:
            config.pop(setting)
    CONFIG = config
    CONTROLLER = controller


def get_controller():
    global CONTROLLER
    return CONTROLLER


def get_config():
    global CONFIG
    return CONFIG


# Generate a uuid secret if the user hasn't specified one.
JWT_FALLBACK_SECRET = uuid.uuid4().hex
# Default JWT expiration time in seconds
JWT_FALLBACK_EXPIRE = 60 * 60 * 24  # 24 hours


def get_jwt_config(default_config=False):
    """Get the JSONWebToken auth configuration from the environment.

    PRODIGY_JWT_SECRET is a shared secret that is used for signing tokens
    and verifying them. Use this secret when generating tokens that will be
    used to authenticate calls to prodigy.

    PRODIGY_JWT_AUDIENCE is set to the web address that prodigy will be running
    at, for example http://localhost:8080. The same value must be used when signing
    the tokens and when verifying them.
    """
    global JWT_FALLBACK_SECRET
    default_secret = None
    default_audience = None
    if default_config is True:
        default_secret = JWT_FALLBACK_SECRET
        default_audience = os.environ.get(ENV_VARS.HOST, "localhost")
    token_secret = os.environ.get(ENV_VARS.JWT_SECRET, default_secret)
    token_audience = os.environ.get(ENV_VARS.JWT_AUDIENCE, default_audience)
    return token_secret, token_audience


def get_basic_auth_config():
    """Get the HTTP Basic Auth configuration for protecting access to the running prodigy
    static files.

    This is not a full security system, and only offers weak-protection against unwanted
    access. This protection should not be used in production without strong passwords and
    the app served over https to encrypt the user/pass that is entered.

    PRODIGY_BASIC_AUTH_PASS is a string variable containing the password to accept.
    PRODIGY_BASIC_AUTH_USER is a string variable containung the user to accept.

    raises: ValueError if only one of the two environment variables is set
    returns: a tuple of (user, password) which will be (None, None) if basic auth is disabled
    """
    basic_password = os.environ.get(ENV_VARS.BASIC_AUTH_PASS, None)
    basic_username = os.environ.get(ENV_VARS.BASIC_AUTH_USER, None)
    if basic_password is None and basic_username is None:
        return None, None
    if basic_password is None or basic_username is None:
        raise ValueError(
            "Invalid configuration."
            "You cannot specify one HTTP basic auth environment variable without the other"
        )
    return basic_username, basic_password


#
# JWT
#


class JWTBearer(HTTPBearer):
    def __init__(
        self,
        jwt_secret: str = None,
        jwt_audience: str = None,
        jwt_algorithm: str = "HS256",
    ):
        super(JWTBearer, self).__init__()
        self.jwt_secret = jwt_secret
        self.jwt_audience = jwt_audience
        self.jwt_algorithm = jwt_algorithm

    async def __call__(self, request: Request) -> Optional[JWTAuthorizationCredentials]:
        if not os.getenv(ENV_VARS.JWT):
            return None
        # Extract auth token from httponly cookie if it's present.
        if JWT_COOKIE_NAME in request.cookies:
            auth = HTTPAuthorizationCredentials(
                scheme="bearer", credentials=request.cookies[JWT_COOKIE_NAME]
            )
        else:
            # If there isn't a cookie, fallback to Authorization header
            auth: HTTPAuthorizationCredentials = await super(JWTBearer, self).__call__(
                request
            )
        try:
            payload = jwt.decode(
                auth.credentials,
                self.jwt_secret,
                algorithms=[self.jwt_algorithm],
                audience=self.jwt_audience,
            )
        except (jwt.PyJWTError, ValidationError) as e:
            raise HTTPException(
                status_code=HTTP_403_FORBIDDEN, detail=f"Token Error: {e}"
            )
        return JWTPayload(**payload)


#
# Application Configuration
#

app = FastAPI(title="Prodigy", description=API_DOCSTRING, version=about.__version__)

if db_state_default:
    # ContextVars is available and db_state_default was created, Python 3.7
    @app.middleware("http")
    async def reset_db_middleware(request: Request, call_next):
        controller = get_controller()
        # Monkeypatch Peewee
        # ref: https://fastapi.tiangolo.com/advanced/sql-databases-peewee/
        db = getattr(controller.db, "db")
        # If it's a Peewee proxy, extract the DB to monkeypatch it
        if isinstance(db, peewee.Proxy):
            db = db.obj
        # If it's Peewee, monkeypatch it
        if isinstance(db, peewee.Database):
            # Prodigy.db.Database could have monkeypatched it already
            if not isinstance(db._state, PeeweeConnectionState):
                db._state = PeeweeConnectionState()
            # Reset the context var state so that other tasks in this async context use
            # the same DB session
            db._state._state.set(db_state_default.copy())
            db._state.reset()
        # End Peewee monkeypatch
        response = await call_next(request)
        return response


def mount_user_files(local_path):
    """Callback to serve a local directory. Used in file loaders to make
    large files like audio or videos available via an URL.

    local_path (unicode / Path): A local directory.
    RETURNS (unicode): The base URL for the served files, e.g. /user_files.
    """
    base_url = "/user_files"
    log(f"API: Mounting static {base_url} from local path: {local_path}")
    app.mount(base_url, StaticFiles(directory=local_path), name="user_files")
    return base_url


def read_files(path):
    """Read the static content once, to avoid reading on each request."""
    with (path / "index.html").open("r", encoding="utf8") as file_:
        index = file_.read()
    with (path / "bundle.js").open("r", encoding="utf8") as file_:
        javascript = file_.read()
    with (path / "favicon.ico").open("rb") as file_:
        favicon = file_.read()
    return index, javascript, favicon


INDEX_HTML, JAVASCRIPT, FAVICON = read_files(STATIC_DIR)
app.mount("/fonts", StaticFiles(directory=str(STATIC_DIR / "fonts")))

#
# Auth
#


def assert_known_session(session_id):
    """Raise a FastAPI error if the given session_id doesn't match the user specified
    list. If the user hasn't specified a list of sessions, any are allowed.
    """
    sessions = get_valid_sessions()
    if sessions is None:
        return
    if session_id is None:
        raise HTTPException(
            status_code=HTTP_403_FORBIDDEN,
            detail="a registered session id is required for this task",
        )
    if session_id not in sessions:
        raise HTTPException(
            status_code=HTTP_403_FORBIDDEN,
            detail="session is not present in recipe specified list",
        )


BASIC_AUTH_CONTROLLER = HTTPBasic()


async def get_basic_auth(request: Request):
    global BASIC_AUTH_CONTROLLER

    # Check for disabled auth configuration before using the auth controller.
    # NOTE: this is so that when auth is disabled the client doesn't get sent
    #       an authorization prompt, which happens when the auth controller is
    #       called by the DepInjector. I tried auto_error=False but then I needed
    #       to call it again later to get the auth challenge headers needed in
    #       a failure response. This ends up being the cleanest way I've found.
    basic_username, basic_password = get_basic_auth_config()
    if basic_password is None and basic_username is None:
        return None
    if basic_password is None or basic_username is None:
        raise ValueError(
            "Invalid configuration."
            "You cannot specify one HTTP basic auth environment variable without the other"
        )

    # Invoke HTTP Basic auth challenge/handler
    credentials: HTTPBasicCredentials = await BASIC_AUTH_CONTROLLER(request)
    if credentials.username != basic_username or credentials.password != basic_password:
        raise HTTPException(
            status_code=HTTP_401_UNAUTHORIZED, detail="Incorrect email or password"
        )
    else:
        return credentials


JWTController = JWTBearer(*get_jwt_config(default_config=True))

static = APIRouter()
routes = APIRouter()


#
# API
#


def serve_main():
    """Serve the main React application and set a httponly cookie
    that enables the client page to make calls to the server."""
    response = HTMLResponse(INDEX_HTML)
    expire = os.getenv(ENV_VARS.JWT_EXPIRE_SECONDS, JWT_FALLBACK_EXPIRE)
    secret, audience = get_jwt_config(default_config=True)
    issuer = os.getenv(ENV_VARS.HOST, audience)
    token = encode_token(secret, audience, issuer, expire)
    response.set_cookie(
        JWT_COOKIE_NAME,
        value=token.decode("utf-8"),
        domain=issuer,
        httponly=True,
        max_age=expire,
        expires=expire,
    )
    return response


@static.get("/")
def static_root():
    return serve_main()


def encode_token(secret, audience, issuer, expire_seconds):
    """Encode a JWT for accessing the prodigy API routes"""
    payload = {
        "exp": datetime.datetime.utcnow() + datetime.timedelta(seconds=expire_seconds),
        "aud": audience,
        "iss": issuer,
    }
    return jwt.encode(payload, secret)


@static.get("/index.html")
def static_index():
    return serve_main()


@static.get("/bundle.js")
def static_bundle():
    return Response(JAVASCRIPT, media_type="application/javascript")


@static.get("/favicon.ico")
def static_favicon():
    return Response(FAVICON, media_type="image/x-icon")


@routes.get("/version", response_model=APIVersionResponse)
def version():
    return dict(
        name="prodigy",
        description=about.__summary__,
        author=about.__author__,
        author_email=about.__email__,
        url=about.__uri__,
        version=about.__version__,
        license=about.__license__,
    )


@routes.get("/project")
def get_project():
    log("GET: /project", get_config())
    assert_known_session(None)
    config = {}
    for key, value in get_config().items():
        if srsly.is_json_serializable(value):
            config[key] = value
    return config


@routes.get("/project/{session_id}")
def get_session_project(session_id: str):
    assert_known_session(session_id)
    controller = get_controller()
    config = {}
    for key, value in get_config().items():
        if srsly.is_json_serializable(value):
            config[key] = value
    # We're in a named session here, so we want to show the totals for the
    # given session, not the whole dataset
    config["total"] = controller.get_total_by_session(session_id)
    return config


def _shared_get_questions(
    session_id: Optional[str] = None, excludes: Optional[List[int]] = None
):
    """Because of route decorators we can't call through
    to another route by invoking the fn directly. Move the
    shared logic here into a plain fn"""
    controller = get_controller()
    if controller.db and hasattr(controller.db, "reconnect"):
        controller.db.reconnect()
    tasks = controller.get_questions(session_id=session_id, excludes=excludes)
    out_session = session_id if session_id is not None else controller.session_id
    response = {
        "tasks": tasks,
        "total": controller.total_annotated,
        "progress": controller.get_progress(session_id),
        "session_id": out_session,
    }
    log(f"RESPONSE: /get_session_questions ({len(tasks)} examples)", response)
    if controller.db and hasattr(controller.db, "close"):
        controller.db.close()
    return response


@routes.get("/get_questions", response_model=APIQuestionsResponse)
def get_questions():
    """Get the next batch of tasks to annotate.
    RETURNS (dict): {'tasks': list, 'total': int, 'progress': float}
    """
    return _shared_get_questions(None)


@routes.post("/get_session_questions", response_model=APIQuestionsResponse)
def get_session_questions(req: APISessionQuestionsRequest):
    """Get the next batch of tasks to annotate for a given session_id

    RETURNS (dict): {'tasks': list, 'total': int, 'progress': float, 'session_id': str}
    """
    log("POST: /get_session_questions")
    return _shared_get_questions(req.session_id, excludes=req.excludes)


@routes.post("/set_session_aliases", response_model=SessionID)
def set_session_aliases(req: SessionID):
    """Set the list of past session_ids to associate with a current session_id. This
    is useful for recipes that require overlap but want to exclude questions an annotator
    has seen before in a previous session for the same task.

    RETURNS (dict): {'session_id': str}
    """
    log("POST: /set_session_aliases")
    controller = get_controller()
    controller.set_session_aliases(req.session_id, req.aliases)
    return {"session_id": req.session_id}


@routes.post("/end_session")
def end_session(req: SessionID):
    """Tell the prodigy controller that it can release the resources held for the
    given session_id.
    """
    log("POST: /end_session")
    controller = get_controller()
    response = controller.end_session(req.session_id)
    log(f"RESPONSE: /end_session ({response})")
    return response


@routes.post("/validate_answer", response_model=APIAnswerValidateResponse)
def validate_answer(req: APIAnswerValidateRequest):
    """Validate an answer that the user intends to submit. This should only
    be called if a validation function has been provided by the recipe.
    """
    log("POST: /validate_answer")
    controller = get_controller()
    if controller.validate_answer:
        try:
            controller.validate_answer(req.answer)
        except Exception as e:
            return {"ok": False, "message": str(e)}
    return {"ok": True, "message": None}


@routes.post("/give_answers", response_model=APIAnswersResponse)
def give_answers(req: APIAnswersRequest):
    """Receive annotated answers, e.g. from the web app.

    answers (list): A list of task dictionaries with an added `"answer"` key.
    session_id (str): The session id string that points to a dataset
    RETURNS (dict): {'progress': float}
    """
    session_id = req.session_id
    answers = req.answers
    id_info = f", session ID '{session_id}'" if session_id else ""
    log(f"POST: /give_answers (received {len(answers)}{id_info})", answers)
    controller = get_controller()
    if controller.db and hasattr(controller.db, "reconnect"):
        controller.db.reconnect()
    controller.receive_answers(answers, session_id=session_id)
    response = {"progress": controller.get_progress(session_id)}
    log("RESPONSE: /give_answers", response)
    if controller.db and hasattr(controller.db, "close"):
        controller.db.close()
    return response


app.include_router(static, tags=["static"], dependencies=[Depends(get_basic_auth)])
app.include_router(routes, tags=["api"], dependencies=[Depends(JWTController)])


def server(controller, config):
    """Serve the Prodigy REST API.

    controller (prodigy.core.Controller): The initialized controller.
    config (dict): Configuration settings, e.g. via a prodigy.json or recipe.
    """
    set_controller(controller, config)

    port = os.getenv(ENV_VARS.PORT, config.get("port", 8080))
    host = os.getenv(ENV_VARS.HOST, config.get("host", "localhost"))
    if config.get("cors", True):
        cors_origin = os.environ.get(ENV_VARS.CORS_ORIGIN, None)
        # If JWTs are configured, specify allow credentials and the cors origin
        if get_jwt_config() is not (None, None) and cors_origin is not None:
            allowed_origins = cors_origin
            if type(allowed_origins) is str:
                allowed_origins = allowed_origins.split(",")
            log(f"CORS: initialized with specific origins: {allowed_origins}")
        else:
            log('CORS: initialized with wildcard "*" CORS origins')
            allowed_origins = ["*"]
        app.add_middleware(
            CORSMiddleware,
            allow_origins=allowed_origins,
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )

    msg.text(
        f"Starting the web server at http://{host}:{port} ...",
        "Open the app in your browser and start annotating!",
        icon="emoji",
        spaced=True,
    )

    # uvicorn doesn't seem to accept our log levels via getLogger, so we also
    # pass it in explicitly here
    uvicorn.run(
        app,
        host=host,
        port=int(port),
        log_level=get_log_level(),
        log_config=_uvicorn_log_config,
    )
    controller.save()
