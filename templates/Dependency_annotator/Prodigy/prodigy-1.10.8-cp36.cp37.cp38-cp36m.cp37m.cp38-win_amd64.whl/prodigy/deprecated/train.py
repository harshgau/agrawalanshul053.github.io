import spacy
from spacy.util import fix_random_seed, minibatch
import random
import tqdm
import srsly
from pathlib import Path
from wasabi import table, row

from .recipes import print_tc_result
from .core import recipe_args
from ..core import recipe
from ..models.ner import EntityRecognizer, merge_spans, guess_batch_size
from ..models.textcat import TextClassifier
from ..models.pos import Tagger, merge_tags
from ..models.dep import DependencyParser, merge_arcs
from ..components.db import connect
from ..components.preprocess import split_sentences, convert_options_to_cats
from ..components import printers
from ..util import load_pretrained_tok2vec, read_pretrain_hyper_params
from ..util import msg, log, color, get_msg, split_evals, export_model_data


@recipe(
    "ner.batch-train",
    dataset=recipe_args["dataset"],
    input_model=recipe_args["spacy_model"],
    init_tok2vec=recipe_args["init_tok2vec"],
    output_model=recipe_args["output"],
    label=recipe_args["label_set"],
    factor=recipe_args["factor"],
    dropout=recipe_args["dropout"],
    n_iter=recipe_args["n_iter"],
    batch_size=recipe_args["batch_size"],
    beam_width=recipe_args["beam_width"],
    eval_id=recipe_args["eval_id"],
    eval_split=recipe_args["eval_split"],
    unsegmented=recipe_args["unsegmented"],
    no_missing=recipe_args["no_missing"],
    silent=recipe_args["silent"],
)
def ner_batch_train(
    dataset,
    input_model,
    output_model=None,
    init_tok2vec=None,
    label="",
    factor=1,
    dropout=0.2,
    n_iter=10,
    batch_size=-1,
    beam_width=16,
    eval_id=None,
    eval_split=None,
    unsegmented=False,
    no_missing=False,
    silent=False,
):
    """
    Batch train a Named Entity Recognition model from annotations. Prodigy will
    export the best result to the output directory, and include a JSONL file of
    the training and evaluation examples. You can either supply a dataset ID
    containing the evaluation data, or choose to split off a percentage of
    examples for evaluation.
    """
    msg.warn(
        "Prodigy now comes with a new general-purpose `train` command that "
        "supports all components and can be used with binary accept/reject "
        "annotations by setting the --binary flag. It also features an "
        "improved training loop and more detailed per-entity-type results. "
        "Give it a try!"
    )
    log("RECIPE: Starting recipe ner.batch-train", locals())
    _msg = get_msg(no_print=silent)
    _print = (lambda string: None) if silent else print
    fix_random_seed(0)
    DB = connect()
    if dataset not in DB:
        msg.fail(f"Can't find dataset '{dataset}'", exits=1)
    if input_model.startswith("blank:"):
        input_model = input_model.replace("blank:", "")
        nlp = spacy.blank(input_model)
    else:
        nlp = spacy.load(input_model)
    _msg.info(f"Loaded model {input_model}")
    if "sentencizer" not in nlp.pipe_names:
        nlp.add_pipe(nlp.create_pipe("sentencizer"), first=True)
        log("RECIPE: Added sentencizer to model pipeline", nlp.pipe_names)
    examples = merge_spans(DB.get_dataset(dataset))
    random.shuffle(examples)
    if "ner" not in nlp.pipe_names:
        ner = nlp.create_pipe("ner")
        if nlp.vocab.vectors.data.size:
            ner.cfg["pretrained_dims"] = nlp.vocab.vectors.data.shape[1]
    else:
        ner = nlp.get_pipe("ner")
    # make sure all labels are present in the model
    for eg in examples:
        for span in eg.get("spans", []):
            ner.add_label(span["label"])
    for l in label:
        ner.add_label(l)
    if "ner" not in nlp.pipe_names:
        nlp.add_pipe(ner, last=True)
        hyper_params = read_pretrain_hyper_params(init_tok2vec, require=False)
        # Only reset weights for NER component
        other_pipes = [pipe for pipe in nlp.pipe_names if pipe != "ner"]
        with nlp.disable_pipes(*other_pipes):
            nlp.begin_training(component_cfg={"ner": hyper_params})
        load_pretrained_tok2vec(ner, init_tok2vec, require=False)
    if eval_id:
        evals = DB.get_dataset(eval_id)
        _msg.text(f"Loaded {len(evals)} evaluation examples from '{eval_id}'")
    else:
        examples, evals, eval_split = split_evals(examples, eval_split)
        _msg.text(f"Using {eval_split:.0%} of examples ({len(evals)}) for evaluation")
    model = EntityRecognizer(nlp, label=label, no_missing=no_missing)
    if batch_size < 1:
        batch_size = guess_batch_size(len(examples))
    other_pipes = [p for p in nlp.pipe_names if p not in ("ner", "sentencizer")]
    if other_pipes:
        disabled = nlp.disable_pipes(other_pipes)
        log(f"RECIPE: Temporarily disabled other pipes: {other_pipes}")
    else:
        disabled = None
    log(f"RECIPE: Initialised EntityRecognizer with model {input_model}")
    if not unsegmented:
        examples = list(split_sentences(model.orig_nlp, examples))
        evals = list(split_sentences(model.orig_nlp, evals))
    else:
        examples = list(examples)
        evals = list(evals)
    baseline = model.evaluate(evals)
    log(f"RECIPE: Calculated baseline from evaluation examples ({baseline['acc']:.2f})")
    best = None
    random.shuffle(examples)
    examples = examples[: int(len(examples) * factor)]
    _print(print_trainconf(dropout, n_iter, batch_size, factor, len(examples)))
    _print(print_format_before(**baseline))
    if len(evals) > 0:
        _msg.row(["#", "LOSS", "RIGHT", "WRONG", "ENTS", "SKIP", "ACCURACY"], widths=10)
    for i in range(n_iter):
        losses = model.batch_train(
            examples, batch_size=batch_size, drop=dropout, beam_width=beam_width
        )
        stats = model.evaluate(evals)
        if best is None or stats["acc"] > best[0]:
            model_to_bytes = None
            if output_model is not None:
                # Only serialize NER because to_bytes uses too much memory with vectors
                with model.nlp.use_params(model.optimizer.averages):
                    model_to_bytes = nlp.get_pipe("ner").to_bytes(exclude=["vocab"])
            best = (stats["acc"], stats, model_to_bytes)
        results = [
            "%02d" % (i + 1),
            "%.3f" % losses["ner"],
            round(stats["right"]),
            round(stats["wrong"]),
            round(stats["ents"]),
            round(losses["skipped"]),
            "%.3f" % stats["acc"],
        ]
        _msg.row(results, widths=10)
    best_acc, best_stats, best_model = best
    _print(print_format_results(best_stats, best_acc, baseline["acc"]))
    if output_model is not None:
        model.nlp.get_pipe("ner").from_bytes(best_model)
        if disabled:
            log(f"RECIPE: Restoring disabled pipes: {other_pipes}")
            disabled.restore()
        result = export_model_data(output_model, model.nlp, examples, evals)
        _print(result)
    best_stats["baseline"] = baseline["acc"]
    best_stats["acc"] = best_acc
    return best_stats


@recipe(
    "ner.train-curve",
    dataset=recipe_args["dataset"],
    input_model=recipe_args["spacy_model"],
    label=recipe_args["label_set"],
    dropout=recipe_args["dropout"],
    n_iter=recipe_args["n_iter"],
    batch_size=recipe_args["batch_size"],
    beam_width=recipe_args["beam_width"],
    eval_id=recipe_args["eval_id"],
    eval_split=recipe_args["eval_split"],
    unsegmented=recipe_args["unsegmented"],
    no_missing=recipe_args["no_missing"],
    n_samples=recipe_args["n_samples"],
)
def ner_train_curve(
    dataset,
    input_model,
    label="",
    init_tok2vec=None,
    dropout=0.2,
    n_iter=5,
    batch_size=32,
    beam_width=16,
    eval_id=None,
    eval_split=None,
    unsegmented=False,
    no_missing=False,
    n_samples=4,
):
    """
    Batch-train models with different portions of the training examples and
    print the accuracy figures and accuracy improvements.
    """
    msg.warn(
        "Prodigy now comes with a new general-purpose `train-curve` command "
        "that supports all components and can be used with binary accept/reject "
        "annotations by setting the --binary flag. Give it a try!"
    )
    log("RECIPE: Starting recipe ner.train-curve", locals())
    factors = [(i + 1) / n_samples for i in range(n_samples)]
    prev_acc = 0
    msg.info(f"Starting with model {input_model}")
    print(print_trainconf(dropout, n_iter, batch_size, samples=n_samples))
    print(printers.ner_curve_header())
    for factor in factors:
        best_stats = ner_batch_train(
            dataset,
            input_model=input_model,
            init_tok2vec=init_tok2vec,
            label=label,
            factor=factor,
            dropout=dropout,
            n_iter=n_iter,
            batch_size=batch_size,
            beam_width=beam_width,
            eval_id=eval_id,
            eval_split=eval_split,
            no_missing=no_missing,
            unsegmented=unsegmented,
            silent=True,
        )
        print(print_format_curve(factor, best_stats, prev_acc))
        prev_acc = best_stats["acc"]


@recipe(
    "textcat.batch-train",
    dataset=recipe_args["dataset"],
    input_model=recipe_args["spacy_model"],
    output_model=recipe_args["output"],
    init_tok2vec=recipe_args["init_tok2vec"],
    exclusive=recipe_args["exclusive"],
    lang=recipe_args["lang"],
    factor=recipe_args["factor"],
    dropout=recipe_args["dropout"],
    n_iter=recipe_args["n_iter"],
    batch_size=recipe_args["batch_size"],
    eval_id=recipe_args["eval_id"],
    eval_split=recipe_args["eval_split"],
    long_text=("Long text", "flag", "L", bool),
    silent=recipe_args["silent"],
)
def textcat_batch_train(
    dataset,
    input_model=None,
    output_model=None,
    init_tok2vec=None,
    lang="en",
    factor=1,
    dropout=0.2,
    n_iter=10,
    exclusive=False,
    batch_size=10,
    eval_id=None,
    eval_split=None,
    long_text=False,
    silent=False,
):
    """
    Batch train a new text classification model from annotations. Prodigy will
    export the best result to the output directory, and include a JSONL file of
    the training and evaluation examples. You can either supply a dataset ID
    containing the evaluation data, or choose to split off a percentage of
    examples for evaluation.
    """
    msg.warn(
        "Prodigy now comes with a new general-purpose `train` command that "
        "supports all components and works with both binary accept/reject "
        "annotations and multiple choice annotations out-of-the-box. It also "
        "features an improved training loop and more detailed per-class results. "
        "Give it a try!"
    )
    log("RECIPE: Starting recipe textcat.batch-train", locals())
    _msg = get_msg(no_print=silent)
    _print = (lambda string: None) if silent else print
    fix_random_seed(0)
    DB = connect()
    if dataset not in DB:
        msg.fail(f"Can't find dataset '{dataset}'", exits=1)
    if input_model is not None:
        nlp = spacy.load(input_model)
        _msg.info(f"Loaded model {input_model}")
    else:
        nlp = spacy.blank(lang)
        _msg.info("Loaded blank model")
    examples = DB.get_dataset(dataset)
    # Make sure that examples in datasets created with a choice interface are
    # converted to "regular" text classification tasks with a "label" key
    examples = convert_options_to_cats(examples, exclusive=exclusive)
    labels = set()
    for eg in examples:
        for label, value in eg["cats"].items():
            labels.add(label)
    labels = list(sorted(labels))
    model = TextClassifier(
        nlp,
        labels,
        long_text=long_text,
        low_data=len(examples) < 1000,
        init_tok2vec=init_tok2vec,
        exclusive_classes=exclusive,
    )
    log(f"RECIPE: Initialised TextClassifier with model {input_model}")
    other_pipes = [p for p in nlp.pipe_names if p not in ("textcat", "sentencizer")]
    if other_pipes:
        disabled = nlp.disable_pipes(other_pipes)
        log(f"RECIPE: Temporarily disabled other pipes: {other_pipes}")
    else:
        disabled = None
    random.shuffle(examples)
    if eval_id:
        evals = DB.get_dataset(eval_id)
        evals = convert_options_to_cats(evals)
        _msg.text(f"Loaded {len(evals)} evaluation examples from '{eval_id}'")
    else:
        examples, evals, eval_split = split_evals(examples, eval_split)
        _msg.text(f"Using {eval_split:.0%} of examples ({len(evals)}) for evaluation")
    random.shuffle(examples)
    examples = examples[: int(len(examples) * factor)]
    _print(print_trainconf(dropout, n_iter, batch_size, factor, len(examples)))
    if len(evals) > 0:
        _msg.row(["#", "LOSS", "F-SCORE", "ACCURACY"], widths=10)
    best_acc = {"accuracy": 0}
    best_model = None
    if long_text:
        examples = list(split_sentences(nlp, examples, min_length=False))
    for i in range(n_iter):
        loss = 0.0
        random.shuffle(examples)
        for batch in minibatch(tqdm.tqdm(examples, leave=False), size=batch_size):
            batch = list(batch)
            loss += model.update(batch, revise=False, drop=dropout)
        if len(evals) > 0:
            with nlp.use_params(model.optimizer.averages):
                acc = model.evaluate(tqdm.tqdm(evals, leave=False))
                if acc["accuracy"] > best_acc["accuracy"]:
                    best_acc = dict(acc)
                    best_model = nlp.to_bytes()
            results = [
                f"{(i + 1):02d}",
                f"{loss:.3f}",
                f"{acc['fscore']:.3f}",
                f"{acc['accuracy']:.3f}",
            ]
            _msg.row(results, widths=10)
    if len(evals) > 0:
        _print(print_tc_result(best_acc))
    if output_model is not None:
        if best_model is not None:
            nlp = nlp.from_bytes(best_model)
            if disabled:
                log(f"RECIPE: Restoring disabled pipes: {other_pipes}")
                disabled.restore()
        result = export_model_data(output_model, nlp, examples, evals)
        _print(result)
    return best_acc["accuracy"]


@recipe(
    "textcat.train-curve",
    dataset=recipe_args["dataset"],
    input_model=recipe_args["spacy_model"],
    init_tok2vec=recipe_args["init_tok2vec"],
    dropout=recipe_args["dropout"],
    n_iter=recipe_args["n_iter"],
    exclusive=recipe_args["exclusive"],
    batch_size=recipe_args["batch_size"],
    eval_id=recipe_args["eval_id"],
    eval_split=recipe_args["eval_split"],
    n_samples=recipe_args["n_samples"],
)
def textcat_train_curve(
    dataset,
    input_model=None,
    init_tok2vec=None,
    dropout=0.2,
    n_iter=5,
    exclusive=False,
    batch_size=10,
    eval_id=None,
    eval_split=None,
    n_samples=4,
):
    """
    Batch-train models with different portions of the training examples and
    print the accuracy figures and accuracy improvements.
    """
    msg.warn(
        "Prodigy now comes with a new general-purpose `train-curve` command "
        "that supports all components and works with both binary accept/reject "
        "annotations and multiple choice annotations out-of-the-box. "
        "Give it a try!"
    )
    log("RECIPE: Starting recipe textcat.train-curve", locals())
    factors = [(i + 1) / n_samples for i in range(n_samples)]
    prev_acc = 0
    if input_model is not None:
        msg.info(f"Starting with model {input_model}")
    else:
        msg.info("Starting with blank model")
    print(print_trainconf(dropout, n_iter, batch_size, samples=n_samples))
    msg.row(["%", "ACCURACY"], widths=10)
    for factor in factors:
        best_acc = textcat_batch_train(
            dataset,
            input_model=input_model,
            init_tok2vec=init_tok2vec,
            factor=factor,
            dropout=dropout,
            n_iter=n_iter,
            exclusive=exclusive,
            batch_size=batch_size,
            eval_id=eval_id,
            eval_split=eval_split,
            silent=True,
        )
        print(print_tc_curve(factor, best_acc, prev_acc))
        prev_acc = best_acc


@recipe(
    "pos.batch-train",
    dataset=recipe_args["dataset"],
    input_model=recipe_args["spacy_model"],
    output_model=recipe_args["output"],
    label=recipe_args["label_set"],
    tag_map=recipe_args["tag_map"],
    factor=recipe_args["factor"],
    dropout=recipe_args["dropout"],
    n_iter=recipe_args["n_iter"],
    batch_size=recipe_args["batch_size"],
    eval_id=recipe_args["eval_id"],
    eval_split=recipe_args["eval_split"],
    unsegmented=recipe_args["unsegmented"],
    silent=recipe_args["silent"],
)
def pos_batch_train(
    dataset,
    input_model,
    output_model=None,
    label="",
    tag_map=None,
    factor=1,
    dropout=0.2,
    n_iter=10,
    batch_size=4,
    eval_id=None,
    eval_split=None,
    unsegmented=False,
    silent=False,
):
    """
    Batch train a tagging model from annotations. Prodigy will
    export the best result to the output directory, and include a JSONL file of
    the training and evaluation examples. You can either supply a dataset ID
    containing the evaluation data, or choose to split off a percentage of
    examples for evaluation.
    """
    msg.warn(
        "Prodigy now comes with a new general-purpose `train` command that "
        "supports all components and can be used with binary accept/reject "
        "annotations by setting the --binary flag. It also features an "
        "improved training loop and more detailed per-tag results. "
        "Give it a try!"
    )
    log("RECIPE: Starting recipe pos.batch-train", locals())
    _msg = get_msg(no_print=silent)
    _print = (lambda string: None) if silent else print
    fix_random_seed(0)
    DB = connect()
    if dataset not in DB:
        msg.fail(f"Can't find dataset '{dataset}'", exits=1)
    nlp = spacy.load(input_model)
    _msg.info(f"Loaded model {input_model}")
    if "sentencizer" not in nlp.pipe_names:
        nlp.add_pipe(nlp.create_pipe("sentencizer"), first=True)
        log("RECIPE: Added sentencizer to model pipeline", nlp.pipe_names)
    examples = merge_tags(DB.get_dataset(dataset))
    random.shuffle(examples)
    if "tagger" not in nlp.pipe_names:
        tagger = nlp.create_pipe("tagger")
    else:
        tagger = nlp.get_pipe("tagger")
    if "tagger" not in nlp.pipe_names:
        nlp.add_pipe(tagger, last=True)
        nlp.begin_training()
    if eval_id:
        evals = DB.get_dataset(eval_id)
        msg.text(f"Loaded {len(evals)} evaluation examples from '{eval_id}'")
    else:
        examples, evals, eval_split = split_evals(examples, eval_split)
        _msg.text(f"Using {eval_split:.0%} of examples ({len(evals)}) for evaluation")
    if tag_map is not None:
        tag_map = get_tag_map(tag_map)
    model = Tagger(nlp, label=label, tag_map=tag_map)
    other_pipes = [p for p in nlp.pipe_names if p not in ("tagger", "sentencizer")]
    if other_pipes:
        disabled = nlp.disable_pipes(other_pipes)
        log(f"RECIPE: Temporarily disabled other pipes: {other_pipes}")
    else:
        disabled = None
    log(f"RECIPE: Initialized Tagger with model {input_model}")
    if not unsegmented:
        examples = list(split_sentences(model.nlp, examples))
        evals = list(split_sentences(model.nlp, evals))
    else:
        examples = list(examples)
        evals = list(evals)
    baseline = model.evaluate(evals)
    log(f"RECIPE: Calculated baseline from evaluation examples ({baseline['acc']:.2f})")
    best = None
    random.shuffle(examples)
    examples = examples[: int(len(examples) * factor)]
    _print(print_trainconf(dropout, n_iter, batch_size, factor, len(examples)))
    _print(print_format_before(**baseline))
    if len(evals) > 0:
        msg.row(["#", "LOSS", "RIGHT", "WRONG", "ACCURACY"], widths=10)
    for i in range(n_iter):
        losses = model.batch_train(examples, batch_size=batch_size, drop=dropout)
        stats = model.evaluate(evals)
        if best is None or stats["acc"] > best[0]:
            model_to_bytes = None
            if output_model is not None:
                model_to_bytes = model.to_bytes()
            best = (stats["acc"], stats, model_to_bytes)
        results = [
            f"{(i + 1):02d}",
            f"{losses['tagger']:.3f}",
            round(stats["right"]),
            round(stats["wrong"]),
            f"{stats['acc']:.3f}",
        ]
        msg.row(results, widths=10)
    best_acc, best_stats, best_model = best
    _print(print_format_results(best_stats, best_acc, baseline["acc"]))
    if output_model is not None:
        model.from_bytes(best_model)
        if disabled:
            log(f"RECIPE: Restoring disabled pipes: {other_pipes}")
            disabled.restore()
        result = export_model_data(output_model, model.nlp, examples, evals)
        _print(result)
    best_stats["baseline"] = baseline["acc"]
    best_stats["acc"] = best_acc
    return best_stats


@recipe(
    "pos.train-curve",
    dataset=recipe_args["dataset"],
    input_model=recipe_args["spacy_model"],
    label=recipe_args["entity_label"],
    tag_map=recipe_args["tag_map"],
    dropout=recipe_args["dropout"],
    n_iter=recipe_args["n_iter"],
    batch_size=recipe_args["batch_size"],
    beam_width=recipe_args["beam_width"],
    eval_id=recipe_args["eval_id"],
    eval_split=recipe_args["eval_split"],
    unsegmented=recipe_args["unsegmented"],
    n_samples=recipe_args["n_samples"],
)
def pos_train_curve(
    dataset,
    input_model,
    label="",
    tag_map=None,
    dropout=0.2,
    n_iter=5,
    batch_size=32,
    beam_width=16,
    eval_id=None,
    eval_split=None,
    unsegmented=False,
    n_samples=4,
):
    """
    Batch-train models with different portions of the training examples and
    print the accuracy figures and accuracy improvements.
    """
    msg.warn(
        "Prodigy now comes with a new general-purpose `train-curve` command "
        "that supports all components and can be used with binary accept/reject "
        "annotations by setting the --binary flag. Give it a try!"
    )
    log("RECIPE: Starting recipe pos.train-curve", locals())
    factors = [(i + 1) / n_samples for i in range(n_samples)]
    prev_acc = 0
    msg.info(f"Starting with model {input_model}")
    print(print_trainconf(dropout, n_iter, batch_size, samples=n_samples))
    msg.row(["%", "RIGHT", "WRONG", "ACCURACY"], widths=10)
    for factor in factors:
        best_stats = pos_batch_train(
            dataset,
            input_model=input_model,
            label=label,
            tag_map=tag_map,
            factor=factor,
            dropout=dropout,
            n_iter=n_iter,
            batch_size=batch_size,
            eval_id=eval_id,
            eval_split=eval_split,
            unsegmented=unsegmented,
            silent=True,
        )
        print(print_format_curve(factor, best_stats, prev_acc))
        prev_acc = best_stats["acc"]


@recipe(
    "dep.batch-train",
    dataset=recipe_args["dataset"],
    input_model=recipe_args["spacy_model"],
    output_model=recipe_args["output"],
    label=recipe_args["label_set"],
    factor=recipe_args["factor"],
    dropout=recipe_args["dropout"],
    n_iter=recipe_args["n_iter"],
    batch_size=recipe_args["batch_size"],
    beam_width=recipe_args["beam_width"],
    eval_id=recipe_args["eval_id"],
    eval_split=recipe_args["eval_split"],
    silent=recipe_args["silent"],
)
def dep_batch_train(
    dataset,
    input_model,
    output_model=None,
    label="",
    factor=1,
    dropout=0.2,
    n_iter=10,
    batch_size=32,
    beam_width=16,
    eval_id=None,
    eval_split=None,
    silent=False,
):
    """
    Batch train a dependency parsing model from annotations. Prodigy will
    export the best result to the output directory, and include a JSONL file of
    the training and evaluation examples. You can either supply a dataset ID
    containing the evaluation data, or choose to split off a percentage of
    examples for evaluation.
    """
    msg.warn(
        "Prodigy now comes with a new general-purpose `train` command that "
        "supports all components and can be used with binary accept/reject "
        "annotations by setting the --binary flag. It also features an "
        "improved training loop. Give it a try!"
    )
    log("RECIPE: Starting recipe dep.batch-train", locals())
    _msg = get_msg(no_print=silent)
    _print = (lambda string: None) if silent else print
    fix_random_seed(0)
    DB = connect()
    if dataset not in DB:
        msg.fail(f"Can't find dataset '{dataset}'", exits=1)
    random.seed(0)
    nlp = spacy.load(input_model)
    msg.info(f"Loaded model {input_model}")
    examples = merge_arcs(DB.get_dataset(dataset))
    random.shuffle(examples)
    if "parser" not in nlp.pipe_names:
        parser = nlp.create_pipe("parser")
        for eg in examples:
            for arc in eg.get("arcs", []):
                parser.add_label(arc["label"])
        nlp.add_pipe(parser, last=True)
        nlp.begin_training()
    else:
        parser = nlp.get_pipe("parser")
        for l in label:
            parser.add_label(l)
    if eval_id:
        evals = DB.get_dataset(eval_id)
        msg.text(f"Loaded {len(evals)} evaluation examples from '{eval_id}'")
    else:
        examples, evals, eval_split = split_evals(examples, eval_split)
        _msg.text(f"Using {eval_split:.0%} of examples ({len(evals)}) for evaluation")
    model = DependencyParser(nlp, label=label)
    other_pipes = [p for p in nlp.pipe_names if p not in ("parser", "sentencizer")]
    if other_pipes:
        disabled = nlp.disable_pipes(other_pipes)
        log(f"RECIPE: Temporarily disabled other pipes: {other_pipes}")
    else:
        disabled = None
    log(f"RECIPE: Initialized DependencyParser with model {input_model}")
    baseline = model.evaluate(evals)
    log(f"RECIPE: Calculated baseline from evaluation examples ({baseline['acc']:.2f})")
    best = None
    random.shuffle(examples)
    examples = examples[: int(len(examples) * factor)]
    _print(print_trainconf(dropout, n_iter, batch_size, factor, len(examples)))
    _print(print_format_before(**baseline))
    if len(evals) > 0:
        msg.row(["#", "LOSS", "RIGHT", "WRONG", "SKIP", "ACCURACY"], widths=10)
    for i in range(n_iter):
        losses = model.batch_train(
            examples, batch_size=batch_size, drop=dropout, beam_width=beam_width
        )
        stats = model.evaluate(evals)
        if best is None or stats["acc"] > best[0]:
            model_to_bytes = None
            if output_model is not None:
                model_to_bytes = model.to_bytes()
            best = (stats["acc"], stats, model_to_bytes)
        results = [
            f"{(i + 1):02d}",
            f"{losses['parser']:.3f}",
            round(stats["right"]),
            round(stats["wrong"]),
            round(losses["skipped"]),
            f"{stats['acc']:.3f}",
        ]
        msg.row(results, widths=10)
    best_acc, best_stats, best_model = best
    _print(printers.format_result(best_stats, best_acc, baseline["acc"]))
    if output_model is not None:
        model.from_bytes(best_model)
        if disabled:
            log(f"RECIPE: Restoring disabled pipes: {other_pipes}")
            disabled.restore()
        result = export_model_data(output_model, model.nlp, examples, evals)
        _print(result)
    best_stats["baseline"] = baseline["acc"]
    best_stats["acc"] = best_acc
    return best_stats


@recipe(
    "dep.train-curve",
    dataset=recipe_args["dataset"],
    input_model=recipe_args["spacy_model"],
    label=recipe_args["label_set"],
    dropout=recipe_args["dropout"],
    n_iter=recipe_args["n_iter"],
    batch_size=recipe_args["batch_size"],
    beam_width=recipe_args["beam_width"],
    eval_id=recipe_args["eval_id"],
    eval_split=recipe_args["eval_split"],
    n_samples=recipe_args["n_samples"],
)
def dep_train_curve(
    dataset,
    input_model,
    label="",
    dropout=0.2,
    n_iter=5,
    batch_size=32,
    beam_width=16,
    eval_id=None,
    eval_split=None,
    n_samples=4,
):
    """
    Batch-train models with different portions of the training examples and
    print the accuracy figures and accuracy improvements.
    """
    msg.warn(
        "Prodigy now comes with a new general-purpose `train-curve` command "
        "that supports all components and can be used with binary accept/reject "
        "annotations by setting the --binary flag. Give it a try!"
    )
    log("RECIPE: Starting recipe dep.train-curve", locals())
    factors = [(i + 1) / n_samples for i in range(n_samples)]
    prev_acc = 0
    msg.info(f"Starting with model {input_model}")
    print(print_trainconf(dropout, n_iter, batch_size, samples=n_samples))
    msg.row(["%", "RIGHT", "WRONG", "ACCURACY"], widths=10)
    for factor in factors:
        best_stats = dep_batch_train(
            dataset,
            input_model=input_model,
            label=label,
            factor=factor,
            dropout=dropout,
            n_iter=n_iter,
            batch_size=batch_size,
            beam_width=beam_width,
            eval_id=eval_id,
            eval_split=eval_split,
            silent=True,
        )
        print(print_format_curve(factor, best_stats, prev_acc))
        prev_acc = best_stats["acc"]


def get_tag_map(tag_map):
    log("RECIPE: Using tag map from file", tag_map)
    if not Path(tag_map).exists():
        msg.fail("Not a valid tag map file", tag_map, exits=1)
    tag_map = srsly.read_json(tag_map)
    return tag_map


def print_tc_curve(factor, best_acc, prev_acc):
    diff = best_acc - prev_acc
    diff_color = "green" if diff > 0 else "red"
    results = [f"{factor:.0%}", f"{best_acc:.2f}", color(f"{diff}:+.2f", diff_color)]
    return row(results, widths=10)


def print_trainconf(dropout, n_iter, batch_size, factor=None, n_ex=None, samples=None):
    cfg = []
    if factor and n_ex:
        cfg.append(f"Using {factor:.0%} of remaining examples ({n_ex}) for training\n")
    cfg += [f"Dropout: {dropout}  \nBatch size: {batch_size}  \nIterations: {n_iter}  "]
    if samples:
        cfg.append(f"Samples: {samples}")
    return "".join(cfg) + "\n"


def print_format_before(right=0.0, wrong=0.0, unk=0.0, acc=0.0, ents=None, **kwargs):
    result = [
        ("BEFORE", f"{acc:.3f}"),
        ("Correct", color(round(right), "green")),
        ("Incorrect", color(round(wrong), "red")),
    ]
    if ents is not None:
        result.append(("Entities", round(ents)))
    result.append(("Unknown", round(unk)))
    return table(result)


def print_format_results(data, acc, before_acc):
    result = [
        ("Correct", color(round(data["right"]), "green") if "right" in data else "n/a"),
        ("Incorrect", color(round(data["wrong"]), "red") if "wrong" in data else "n/a"),
        ("Baseline", f"{before_acc:.3f}"),
        ("Accuracy", f"{acc:.3f}"),
    ]
    return table(result)


def print_format_curve(factor, data, prev_acc):
    diff = data["acc"] - prev_acc
    results = [
        f"{factor:.0%}",
        round(data["right"]),
        round(data["wrong"]),
        f"{data['acc']:.2f}",
        color(f"{diff:+.2f}", "green" if diff > 0 else "red"),
    ]
    return row(results, widths=10)
