from pathlib import Path
import spacy
from spacy.pipeline import merge_entities, merge_noun_chunks
import srsly
import copy
from wasabi import table

from .core import recipe_args
from ..core import recipe
from ..components.loaders import get_stream
from ..components.db import connect
from ..components.printers import pretty_print_ner, pretty_print_tc
from ..components.preprocess import split_sentences, add_labels_to_stream, fetch_media
from ..components.filters import filter_inputs
from ..models.matcher import PatternMatcher
from ..models.ner import EntityRecognizer
from ..models.textcat import TextClassifier
from ..models.pos import merge_tags
from ..util import b64_uri_to_bytes, log, set_hashes, msg, color


@recipe(
    "ner.match",
    # fmt: off
    dataset=recipe_args["dataset"],
    spacy_model=recipe_args["spacy_model"],
    source=recipe_args["source"],
    api=recipe_args["api"],
    loader=recipe_args["loader"],
    patterns=recipe_args["patterns"],
    exclude=recipe_args["exclude"],
    resume=("Resume from existing dataset and update matcher accordingly", "flag", "R", bool),
    # fmt: on
)
def match(
    dataset,
    spacy_model,
    patterns,
    source="-",
    api=None,
    loader=None,
    exclude=None,
    resume=False,
):
    """
    DEPRECATED: Use ner.manual with --patterns instead.
    Suggest phrases that match a given patterns file, and mark whether they
    are examples of the entity you're interested in. The patterns file can
    include exact strings or token patterns for use with spaCy's `Matcher`.
    """
    msg.warn(
        "As of v1.9 the ner.match recipe is deprecated. Instead you can now "
        "use the ner.manual recipe with --patterns to annotate and correct "
        "pattern matches.",
    )
    log("RECIPE: Starting recipe ner.match", locals())
    DB = connect()
    model = PatternMatcher(spacy.load(spacy_model)).from_disk(patterns)
    log(f"RECIPE: Created PatternMatcher using model {spacy_model}")
    if resume and dataset is not None and dataset in DB:
        existing = DB.get_dataset(dataset)
        log(f"RECIPE: Updating matcher with {len(existing)} examples from '{dataset}'")
        model.update(existing)
    stream = get_stream(source, api, loader, rehash=True, dedup=True, input_key="text")
    stream = (eg for _, eg in model(stream))
    return {"view_id": "ner", "dataset": dataset, "stream": stream, "exclude": exclude}


@recipe(
    "ner.eval",
    dataset=recipe_args["dataset"],
    model=recipe_args["spacy_model"],
    source=recipe_args["source"],
    api=recipe_args["api"],
    loader=recipe_args["loader"],
    label=recipe_args["label_set"],
    exclude=recipe_args["exclude"],
    whole_text=recipe_args["whole_text"],
    unsegmented=recipe_args["unsegmented"],
)
def ner_eval(
    dataset,
    model,
    source="-",
    api=None,
    loader=None,
    label=None,
    exclude=None,
    whole_text=False,
    unsegmented=False,
):
    """
    DEPRECATED: Use the regular NER annotation interfaces to create evaluation
    sets instead.
    Evaluate an NER model and build an evaluation set from a stream.
    """
    msg.warn(
        "As of v1.9 the ner.eval recipe is deprecated. If you want to create "
        "an evaluation set, either use the ner.manual or ner.correct recipes "
        "and then set the dataset name as the --eval-id when you train."
    )
    log("RECIPE: Starting recipe ner.evaluate", locals())
    model = EntityRecognizer(spacy.load(model), label=label)
    stream = get_stream(source, api=api, loader=loader, rehash=True, input_key="text")
    if not unsegmented:
        stream = split_sentences(model.nlp, stream)

    def get_tasks(model, stream):
        tuples = ((eg["text"], eg) for eg in stream)
        for i, (doc, eg) in enumerate(model.nlp.pipe(tuples, as_tuples=True)):
            ents = [(ent.start_char, ent.end_char, ent.label_) for ent in doc.ents]
            if model.labels:
                ents = [seL for seL in ents if seL[2] in model.labels]

            eg["label"] = "all correct"
            ents = [{"start": s, "end": e, "label": L} for s, e, L in ents]
            if whole_text:
                eg["spans"] = ents
                eg = set_hashes(eg, overwrite=True)
                yield eg
            else:
                for span in ents:
                    task = copy.deepcopy(eg)
                    task["spans"] = [span]
                    task = set_hashes(task, overwrite=True)
                    yield task

    return {
        "view_id": "classification",
        "dataset": dataset,
        "stream": get_tasks(model, stream),
        "exclude": exclude,
        "config": {"lang": model.nlp.lang},
    }


@recipe(
    # fmt: off
    "ner.iob-to-gold",
    input_file=("Path to IOB or IOB2 formatted NER annotations", "positional", None, Path),
    output_file=("Path to write the .jsonl formatted output", "positional", None, Path),
    # fmt: on
)
def iob_to_gold(input_file, output_file=None):
    """
    DEPRECATED: Use spaCy's converters instead.
    Convert a file with IOB tags into JSONL format for use in Prodigy.

    The input format should have one line per text, with whitespace-delimited
    tokens. Each token should have two or more fields delimited by the |
    character. The first field should be the text, and the last an IOB or IOB2
    formatted NER tag.

    Example (IOB):
    Then|RB|O ,|,|O the|DT|I-MISC International|NNP|I-MISC became|VBD|O polarised|VBN|O

    Example (IOB2):
    Then|RB|O ,|,|O the|DT|B-MISC International|NNP|I-MISC became|VBD|O polarised|VBN|O

    If no output is specified, the output is printed to stdout.
    """
    msg.warn(
        "As of v1.9, the ner.iob-to-gold recipe is deprecated because it only "
        "served a very narrow purpose. To convert IOB annotations, you can "
        "either run `spacy.convert` or write a custom script using spaCy's "
        "gold.offsets_from_biluo_tags helper."
    )
    vocab = spacy.vocab.Vocab()
    golds = []
    with input_file.open("r", encoding="utf8") as f:
        for line in f:
            tokens = [t.split("|") for t in line.split() if t.strip()]
            if not tokens:
                continue
            words = [token[0] for token in tokens]
            iob = [token[-1] for token in tokens]
            doc = spacy.tokens.Doc(vocab, words=words)
            offsets = spacy.gold.offsets_from_biluo_tags(
                doc, spacy.gold.iob_to_biluo(iob)
            )
            text = doc.text
            spans = [
                {"text": text[s:e], "label": L, "start": s, "end": e}
                for s, e, L in offsets
            ]
            task = {"text": doc.text, "spans": spans, "no_missing": True}
            task = set_hashes(task)
            golds.append(task)
            if output_file is None:
                print(srsly.json_dumps(task))
    if output_file is not None:
        log(f"RECIPE: Converted {len(golds)} annotations")
        srsly.write_jsonl(output_file, golds)
        msg.good(f"Converted {len(golds)} annotations", output_file)


@recipe(
    "ner.gold-to-spacy",
    # fmt: off
    dataset=recipe_args["dataset"],
    output_file=recipe_args["output_file"],
    spacy_model=("Optional spaCy model for tokenization, required for BILUO mode", "option", "sm", str),
    biluo=("Encode labelled spans into per-token BILUO tags", "flag", "B", bool),
    # fmt: on
)
def ner_gold_to_spacy(dataset, output_file=None, spacy_model=None, biluo=False):
    """
    DEPRECATED: Use spaCy's converters instead.
    Convert a dataset of gold-standard NER annotations (created with ner.manual
    or ner.make-gold) into training data for spaCy. Will export a JSONL file
    with one entry per line:
        >>> ["I like London", {"entities": [[7, 13, "LOC"]]}]
    If no output file is specified, the lines will be printed to stdout.
    BILUO requires a spaCy model for tokenization, which should be the same
    model used during annotation. The BILUO data will look like this:
        >>> ["I like London", ["O", "O", "U-LOC", "O"]]
    """
    msg.warn(
        "As of v1.9 the ner.gold-to-spacy recipe is deprecated in favor of the "
        "much more flexible data-to-spacy recipe that takes one or more "
        "datasets of different types and outputs data in spaCy's JSON format "
        "to use with `spacy train`."
    )
    log("RECIPE: Starting recipe ner.gold-to-spacy", locals())
    DB = connect()
    if dataset not in DB:
        msg.fail(f"Can't find dataset '{dataset}'", exits=1)
    examples = DB.get_dataset(dataset)
    examples = [eg for eg in examples if eg["answer"] == "accept"]
    if biluo:
        if not spacy_model:
            msg.fail("BILUO format requires a spaCy model for tokenization", exits=1)
        nlp = spacy.load(spacy_model)
    log(f"RECIPE: Loaded model {spacy_model}")
    log("RECIPE: Iterating over annotations in the dataset")
    annotations = []
    for eg in examples:
        entities = [(s["start"], s["end"], s["label"]) for s in eg.get("spans", [])]
        if biluo:
            doc = nlp(eg["text"])
            entities = spacy.gold.biluo_tags_from_offsets(doc, entities)
            annot_entry = [eg["text"], entities]
        else:
            annot_entry = [eg["text"], {"entities": entities}]
        annotations.append(annot_entry)
        if not output_file:
            print(srsly.json_dumps(annot_entry))
    if output_file:
        log(f"RECIPE: Generated {len(annotations)} examples")
        srsly.write_jsonl(output_file, annotations)
        msg.good(f"Exported {len(annotations)} examples", output_file)


@recipe(
    "ner.print-best",
    dataset=recipe_args["dataset"],
    spacy_model=recipe_args["spacy_model"],
    pretty=("Pretty-print output", "flag", "P", bool),
)
def print_best(dataset, spacy_model, pretty=False):
    """
    DEPRECATED: Use custom recipe instead or export data directly.
    Predict the highest-scoring parse for examples in a dataset. Scores are
    calculated using the annotations in the dataset, and the statistical model.
    """
    msg.warn(
        "As of v1.9 the ner.print-best recipe is deprecated. Instead, you can "
        "use a custom recipe or export the data directly to a file."
    )
    log("RECIPE: Starting recipe ner.best-parse", locals())
    DB = connect()
    if dataset not in DB:
        msg.fail(f"Can't find dataset '{dataset}'", exits=1)
    model = EntityRecognizer(spacy.load(spacy_model))
    log(f"RECIPE: Initialized EntityRecognizer with model {spacy_model}")
    log("RECIPE: Outputting stream of examples")
    stream = model.make_best(DB.get_dataset(dataset))
    if pretty:
        pretty_print_ner(stream)
    else:
        for eg in stream:
            print(srsly.json_dumps(eg))


@recipe(
    "ner.print-stream",
    spacy_model=recipe_args["spacy_model"],
    source=recipe_args["source"],
    api=recipe_args["api"],
    loader=recipe_args["loader"],
    label=recipe_args["label_set"],
)
def ner_print_stream(spacy_model, source="-", api=None, loader=None, label=""):
    """
    DEPRECATED: Use new general-purpose print-stream recipe instead.
    Pretty print stream output.
    """
    msg.warn(
        "As of v1.9 the ner.print-stream recipe is deprecated in favor of the "
        "more flexible print-stream recipe that can print streams of different "
        "types."
    )
    log("RECIPE: Starting recipe ner.print-stream", locals())

    def add_entities(stream, nlp, labels=None):
        for eg in stream:
            doc = nlp(eg["text"])
            ents = [
                {"start": e.start_char, "end": e.end_char, "label": e.label_}
                for e in doc.ents
                if not labels or e.label_ in labels
            ]
            if ents:
                eg["spans"] = ents
                yield eg

    nlp = spacy.load(spacy_model)
    stream = get_stream(source, api, loader, rehash=True, input_key="text")
    stream = add_entities(stream, nlp, label)
    pretty_print_ner(stream)


@recipe("ner.print-dataset", dataset=recipe_args["dataset"])
def ner_print_dataset(dataset):
    """
    DEPRECATED: Use new general-purpose print-dataset recipe instead.
    Pretty print dataset.
    """
    msg.warn(
        "As of v1.9 the ner.print-dataset recipe is deprecated in favor of the "
        "more flexible print-dataset recipe that can print datasets of "
        "different types."
    )
    log("RECIPE: Starting recipe ner.print-dataset", locals())
    DB = connect()
    if dataset not in DB:
        msg.fail(f"Can't find dataset '{dataset}'", exits=1)
    examples = DB.get_dataset(dataset)
    if not examples:
        msg.fail(f"Can't load '{dataset}' from database {DB.db_name}", exits=1)
    pretty_print_ner(examples)


@recipe(
    "textcat.eval",
    dataset=recipe_args["dataset"],
    spacy_model=recipe_args["spacy_model"],
    source=recipe_args["source"],
    label=recipe_args["label_set"],
    api=recipe_args["api"],
    loader=recipe_args["loader"],
    exclude=recipe_args["exclude"],
)
def textcat_eval(
    dataset, spacy_model, source="-", label="", api=None, loader=None, exclude=None
):
    """
    DEPRECATED: Use textcat.manual to create regular evaluation set instead.
    Evaluate a text classification model and build an evaluation set from a
    stream.
    """
    msg.warn(
        "As of v1.9 the textcat.eval recipe is deprecated. If you want to create "
        "an evaluation set, use the textcat.manual recipe and then set the "
        "dataset name as the --eval-id when you train."
    )
    log("RECIPE: Starting recipe textcat.eval", locals())
    if label is None:
        msg.fail("textcat.eval requires at least one --label", exits=1)
    nlp = spacy.load(spacy_model, disable=["tagger", "parser", "ner"])
    stream = get_stream(source, api, loader)
    stream = add_labels_to_stream(stream, label)
    model = TextClassifier(nlp, label)
    log(f"RECIPE: Initialized TextClassifier with model {spacy_model}")

    def on_exit(ctrl):
        examples = ctrl.db.get_dataset(dataset)
        data = dict(model.evaluate(examples))
        print(print_tc_result(data))

    return {
        "view_id": "classification",
        "dataset": dataset,
        "stream": stream,
        "exclude": exclude,
        "on_exit": on_exit,
        "config": {"lang": nlp.lang, "labels": model.labels},
    }


@recipe(
    "textcat.print-stream",
    source=recipe_args["source"],
    label=recipe_args["label"],
    api=recipe_args["api"],
    loader=recipe_args["loader"],
)
def pretty_print_stream(source="-", label="", api=None, loader=None):
    """
    DEPRECATED: Use new general-purpose print-stream recipe instead.
    Pretty print stream output.
    """
    msg.warn(
        "As of v1.9 the textcat.print-stream recipe is deprecated in favor of "
        "the more flexible print-stream recipe that can print streams of "
        "different types."
    )
    log("RECIPE: Starting recipe textcat.print-stream", locals())
    stream = get_stream(source, api, loader)
    pretty_print_tc(stream, label)


@recipe("textcat.print-dataset", dataset=recipe_args["dataset"])
def pretty_print_dataset(dataset):
    """
    DEPRECATED: Use new general-purpose print-dataset recipe instead.
    Pretty print dataset.
    """
    msg.warn(
        "As of v1.9 the textcat.print-dataset recipe is deprecated in favor of "
        "the more flexible print-dataset recipe that can print datasets of "
        "different types."
    )
    log("RECIPE: Starting recipe textcat.print-dataset", locals())
    DB = connect()
    if dataset not in DB:
        msg.fail(f"Can't find dataset '{dataset}'", exits=1)
    examples = DB.get_dataset(dataset)
    if not examples:
        msg.fail(f"Can't load '{dataset}' from database {DB.db_name}", exits=1)
    pretty_print_tc(examples)


@recipe(
    "pos.gold-to-spacy",
    dataset=recipe_args["dataset"],
    output_file=recipe_args["output_file"],
)
def pos_gold_to_spacy(dataset, output_file=None):
    """
    DEPRECATED: Use spaCy's converters instead
    Convert a dataset with annotated part-of-speech tags to the format required
    to train spaCy's part-of-speech tagger. Will export a JSONL file with one
    entry per line: ["I like eggs", {"tags": ["NOUN", "VERB", "NOUN"]}]
    If no output file is specified, the lines will be printed to stdout.
    The data will be formatted in the "simple training style" and can be
    read in and used to update the tagger. See the spaCy documentation:
    https://spacy.io/usage/training#example-train-tagger
    """
    msg.warn(
        "As of v1.9 the pos.gold-to-spacy recipe is deprecated in favor of the "
        "much more flexible data-to-spacy recipe that takes one or more "
        "datasets of different types and outputs data in spaCy's JSON format "
        "to use with `spacy train`."
    )
    log("RECIPE: Starting recipe pos.gold-to-tags", locals())
    DB = connect()
    if dataset not in DB:
        msg.fail(f"Can't find dataset '{dataset}'", exits=1)
    examples = DB.get_dataset(dataset)
    examples = [eg for eg in examples if eg["answer"] == "accept"]
    examples = merge_tags(examples)
    tags_data = []
    skipped_count = 0
    log("RECIPE: Iterating over annotations in the dataset")
    for eg in examples:
        tags = []
        span_tokens = {}
        for span in eg.get("spans", []):
            token_start = span["token_start"]
            if (token_start + 1) != span["token_end"]:
                # skip example if annotated span contains more than one token
                skipped_count += 1
                log(
                    f"RECIPE: Skipping example with invalid span. POS tag spans can't "
                    f"contain multiple tokens (start {token_start}, end {span['token_end']})",
                    span,
                )
            else:
                span_tokens[token_start] = span
        if span_tokens:
            for token in eg.get("tokens", []):
                tag = "-"  # default tag: no tag assigned
                if token["id"] in span_tokens:
                    tag = span_tokens[token["id"]]["label"]
                tags.append(tag)
            if tags:
                tags_entry = [eg["text"], {"tags": tags}]
                tags_data.append(tags_entry)
                if not output_file:
                    print(srsly.json_dumps(tags_entry))
    if output_file:
        log(f"RECIPE: Generated {len(tags_data)} examples")
        srsly.write_jsonl(output_file, tags_data)
        msg.text(
            f"Exported {len(tags_data)} examples (skipped {skipped_count} containing invalid spans)",
            output_file,
        )


class SentenceIterator(object):
    """Wrap sentences as an iterator for gensim"""

    def __init__(self, nlp, get_stream):
        self.nlp = nlp
        self.get_stream = get_stream
        self.n = 0

    def __len__(self):
        return self.n

    def __iter__(self):
        stream = self.get_stream()
        self.n = 0
        for doc in self.nlp.pipe((eg["text"] for eg in stream)):
            for sent in doc.sents:
                yield [w.text for w in sent]
                self.n += 1


@recipe(
    "terms.train-vectors",
    output_model=recipe_args["output_model"],
    source=recipe_args["source_file"],
    loader=recipe_args["loader"],
    spacy_model=("Loadable spaCy model", "option", "sm", str),
    lang=recipe_args["lang"],
    size=("Dimension of the word vectors", "option", "d", int),
    window=("Context window size", "option", "w", int),
    min_count=("Min count", "option", "m", int),
    negative=("Number of negative samples", "option", "g", int),
    n_iter=recipe_args["n_iter"],
    n_workers=("Number of workers", "option", "nw", int),
    merge_ents=("Merge named entities", "flag", "ME", bool),
    merge_nps=("Merge noun phrases", "flag", "MN", bool),
)
def train_vectors(
    output_model,
    source="-",
    loader=None,
    spacy_model=None,
    lang="xx",
    size=128,
    window=5,
    min_count=10,
    negative=5,
    n_iter=2,
    n_workers=4,
    merge_ents=False,
    merge_nps=False,
):
    """DEPRECATED: Train word vectors from a text source."""
    msg.warn(
        "As of v1.9 the terms.train-vectors recipe is deprecated, since "
        "wrapping word vector training in a recipe only introduces a layer of "
        "unnecessary abstraction. If you want to train your own vectors, use "
        "GloVe, fastText or Gensim directly and then add the vectors to a "
        "spaCy model."
    )
    try:
        from gensim.models import Word2Vec
    except ImportError:
        msg.fail("Can't load Word2Vec. Make sure you have Gensim installed.", exits=1)

    log("RECIPE: Starting recipe terms.train-vectors", locals())
    if spacy_model is None:
        nlp = spacy.blank(lang)
        print(f"Using blank spaCy model ({lang})")
        nlp.add_pipe(nlp.create_pipe("sentencizer"))
        log("RECIPE: Added sentence boundary detector to blank model")
    else:
        nlp = spacy.load(spacy_model)
    if merge_ents:
        nlp.add_pipe(merge_entities, name="merge_entities")
        log("RECIPE: Added pipeline component to merge entities")
    if merge_nps:
        nlp.add_pipe(merge_noun_chunks, name="merge_noun_chunks")
        log("RECIPE: Added pipeline component to merge noun chunks")
    if not output_model.exists():
        output_model.mkdir(parents=True)
        log("RECIPE: Created output directory")
    sentences = SentenceIterator(
        nlp, lambda: get_stream(source, loader=loader, input_key="text")
    )
    w2v = Word2Vec(
        sentences,
        size=size,
        window=window,
        min_count=min_count,
        sample=1e-5,
        iter=n_iter,
        workers=n_workers,
        negative=negative,
    )
    log(f"RECIPE: Resetting vectors with size {size}")
    nlp.vocab.reset_vectors(width=size)
    log(f"RECIPE: Adding {len(w2v.wv.vocab)} vectors to model vocab")
    for word in w2v.wv.vocab:
        nlp.vocab.set_vector(word, w2v.wv.word_vec(word))
    nlp.to_disk(output_model)
    msg.good("Trained Word2Vec model", output_model.resolve())
    return False


@recipe(
    "image.test",
    dataset=recipe_args["dataset"],
    lightnet_model=("Loadable lightnet model", "positional", None, str),
    source=recipe_args["source"],
    api=recipe_args["api"],
    exclude=recipe_args["exclude"],
)
def image_test(dataset, lightnet_model, source="", api=None, exclude=None):
    """
    DEPRECATED: Test Prodigy's image annotation interface with a YOLOv2 model
    loaded via LightNet. Requires the LightNet library to be installed. The
    recipe will find objects in the images, and create a task for each object.
    """
    msg.warn(
        "As of v1.9 the image.test recipe is deprecated, since it was mostly "
        "intended to demonstrate the new image capabilities on launch. For a "
        "real-world example of using Prodigy for object detection with a model "
        "in the loop, see this TensorFlow tutorial: https://support.prodi.gy/t/1965"
    )
    log("RECIPE: Starting recipe image.test", locals())
    try:
        import lightnet
    except ImportError:
        msg.fail("Can't find LightNet: https://github.com/explosion/lightnet", exits=1)

    def get_image_stream(model, stream, thresh=0.5):
        for eg in stream:
            if not eg["image"].startswith("data"):
                err = f"Expected base64-encoded data URI. Got: '{eg['image'][:100]}'"
                msg.fail(err, exits=1)
            image = lightnet.Image.from_bytes(b64_uri_to_bytes(eg["image"]))
            boxes = [b for b in model(image, thresh=thresh) if b[2] >= thresh]
            eg["width"] = image.width
            eg["height"] = image.height
            eg["spans"] = [get_span(box) for box in boxes]
            for i in range(len(eg["spans"])):
                task = copy.deepcopy(eg)
                task["spans"][i]["hidden"] = False
                task = set_hashes(task, overwrite=True)
                score = task["spans"][i]["score"]
                task["score"] = score
                yield task

    def get_span(box, hidden=True):
        class_id, name, prob, abs_points = box
        name = str(name, "utf8") if not isinstance(name, str) else name
        x, y, w, h = abs_points
        rel_points = [
            [x - w / 2, y - h / 2],
            [x - w / 2, y + h / 2],
            [x + w / 2, y + h / 2],
            [x + w / 2, y - h / 2],
        ]
        return {
            "score": prob,
            "label": name,
            "label_id": class_id,
            "points": rel_points,
            "center": [abs_points[0], abs_points[1]],
            "hidden": hidden,
        }

    model = lightnet.load(lightnet_model)
    log(f"RECIPE: Loaded LightNet model {lightnet_model}")
    stream = get_stream(source, api, loader="images", input_key="image")
    stream = fetch_media(stream, ["image"])
    stream = get_image_stream(model, stream)

    def free_lighnet(ctrl):
        nonlocal model
        del model

    return {
        "view_id": "image",
        "dataset": dataset,
        "stream": stream,
        "exclude": exclude,
        "on_exit": free_lighnet,
    }


@recipe(
    "pipe",
    source=recipe_args["source"],
    api=recipe_args["api"],
    loader=recipe_args["loader"],
    from_dataset=("Stream from a dataset", "flag", "D"),
    exclude=recipe_args["exclude"],
)
def pipe(source="-", api=None, loader=None, from_dataset=False, exclude=None):
    """
    DEPRECATED: This command is deprecated, since it didn't provide any
    Prodigy-specific functionality. To pipe data forward, you can convert the
    data to JSONL and run `cat data.jsonl | prodigy ...` or write a custom loader.

    Convert data to JSONL and then pipe forward instead.
    Load examples from an input source, and print them as newline-delimited
    JSON. This makes it easy to filter the stream with command-line utilities
    such as `grep`. It's also often useful to inspect the stream, by piping to
    `less`.
    """
    DB = connect()
    if from_dataset:
        stream = DB.get_dataset(source)
    else:
        stream = get_stream(source, api, loader)
        stream = (set_hashes(eg) for eg in stream)
    if exclude:
        log(f"RECIPE: Excluding tasks from datasets: {', '.join(exclude)}")
        exclude_hashes = DB.get_input_hashes(*exclude)
        stream = filter_inputs(stream, exclude_hashes)
    try:
        for eg in stream:
            print(srsly.json_dumps(eg))
    except KeyboardInterrupt:
        pass


@recipe(
    "dataset",
    set_id=recipe_args["dataset"],
    description=("Dataset description", "positional", None, str),
    author=("Dataset author", "option", "a", str),
)
def dataset(set_id, description=None, author=None):
    """
    DEPRECATED: Datasets are now created automatically when you need them.
    Create a new Prodigy dataset. This lets you assign meta information,
    like a description, and will add the new set to the database. In order to
    collect annotations and save the results, Prodigy expects a dataset ID to
    exist in the database.
    """
    DB = connect()
    if set_id in DB:
        msg.fail(f"'{set_id}' already exists in database {DB.db_name}", exits=1)
    meta = {"description": description, "author": author}
    created = DB.add_dataset(set_id, meta)
    if not created:
        msg.fail(f"Couldn't add '{set_id}' to database {DB.db_name}", exits=1)
    msg.good(f"Successfully added '{set_id}' to database {DB.db_name}")


def print_tc_result(data):
    for key in ["tp", "fp", "tn", "fn"]:
        if key in data:
            data[key] = round(data[key])
    na = "n/a"
    tp = data.get("tp", na)
    fp = data.get("fp", na)
    tn = data.get("tn", na)
    fn = data.get("fn", na)
    correct = tp + tn if "tp" in data and "tn" in data else na
    incorrect = fp + fn if "fp" in data and "fn" in data else na
    baseline = "%.2f" % data["baseline"] if "baseline" in data else na
    precision = "%.2f" % data["precision"] if "precision" in data else na
    recall = "%.2f" % data["recall"] if "recall" in data else na
    fscore = "%.2f" % data["fscore"] if "fscore" in data else na
    accuracy = "%.2f" % data["accuracy"] if "accuracy" in data else na
    result1 = [
        ("accept", "accept", tp),
        ("accept", "reject", fp),
        ("reject", "reject", tn),
        ("reject", "accept", fn),
    ]
    result2 = [
        ("Correct", color(correct, "green")),
        ("Incorrect", color(incorrect, "red")),
    ]
    result3 = [
        ("Baseline", baseline),
        ("Precision", precision),
        ("Recall", recall),
        ("F-score", fscore),
        ("Accuracy", color(accuracy, "green")),
    ]
    return table(result1) + table(result2) + table(result3)
